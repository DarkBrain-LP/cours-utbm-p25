package iterator;

import model.TreeNode;
import java.util.Stack;

/**
 * Implements a pre-order depth-first traversal iterator (NLR - Node, Left,
 * Right). It returns the parent node before its child nodes. [cite: 33]
 *
 * @param <N> The type of the tree node.
 * @param <D> The type of the data stored in the tree node.
 */
public class DepthNLRTreeNodeIterator<N extends TreeNode<N, D>, D> extends AbstractArrayBasedTreeNodeIterator<N, D> {

	private final Stack<N> stack;

	/**
	 * Constructs a DepthNLRTreeNodeIterator starting from the specified root.
	 * 
	 * @param root The root node for the traversal.
	 */
	public DepthNLRTreeNodeIterator(N root) {
		super(root);
		this.stack = new Stack<>();
		if (root != null) {
			this.stack.push(root); // Start with the root node
		}
	}

	@Override
	public boolean hasNext() {
		return !this.stack.isEmpty();
	}

	@Override
	public N next() {
		if (!hasNext()) {
			String s = "No more nodes in the pre-order traversal."; //$NON-NLS-1$
			throw new java.util.NoSuchElementException(s);
		}
		N currentNode = this.stack.pop();

		// Push children in reverse order so that the left child is processed first
		// (LIFO stack)
		// For pre-order NLR, we want to visit N, then L, then R.
		// So, push R first, then L, so L is popped before R.
		// This assumes getChildren() returns children in left-to-right order.
		java.util.List<N> children = new java.util.ArrayList<>(currentNode.getChildren());
		java.util.Collections.reverse(children); // Reverse to push right child first
		for (N child : children) {
			this.stack.push(child);
		}

		return currentNode;
	}
}