package iterator;

import model.TreeNode;
import java.util.Iterator;

/**
 * An iterator for traversing the data elements stored within the nodes of a
 * tree. It uses an underlying {@link Iterator} over {@link TreeNode}s to access
 * the data. [cite: 36]
 *
 * @param <N> The type of the tree node.
 * @param <D> The type of the data stored in the tree node.
 */
public class DataIterator<N extends TreeNode<N, D>, D> implements Iterator<D> {

	private final Iterator<N> nodeIterator;
	private Iterator<D> currentDataIterator;

	/**
	 * Constructs a DataIterator with a reference to a node iterator.
	 *
	 * @param nodeIterator An iterator that provides tree nodes.
	 */
	public DataIterator(Iterator<N> nodeIterator) {
		if (nodeIterator == null) {
			throw new IllegalArgumentException("Node iterator cannot be null."); //$NON-NLS-1$
		}
		this.nodeIterator = nodeIterator;
		// Initialize currentDataIterator to the data of the first available node
		findNextDataIterator();
	}

	private void findNextDataIterator() {
		// Loop until we find a node with data or run out of nodes
		while ((this.currentDataIterator == null || !this.currentDataIterator.hasNext()) && this.nodeIterator.hasNext()) {
			N nextNode = this.nodeIterator.next();
			if (nextNode != null && !nextNode.getData().isEmpty()) {
				this.currentDataIterator = nextNode.getData().iterator();
			}
		}
	}

	@Override
	public boolean hasNext() {
		// Ensure we always have the next available data iterator
		findNextDataIterator();
		return this.currentDataIterator != null && this.currentDataIterator.hasNext();
	}

	@Override
	public D next() {
		if (!hasNext()) {
			throw new java.util.NoSuchElementException("No more data elements in the tree."); //$NON-NLS-1$
		}
		return this.currentDataIterator.next();
	}

	/**
	 * This operation is not supported by this iterator.
	 * 
	 * @throws UnsupportedOperationException always.
	 */
	@Override
	public void remove() {
		throw new UnsupportedOperationException("Remove operation is not supported by this iterator."); //$NON-NLS-1$
	}
}