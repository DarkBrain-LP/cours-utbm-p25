package iterator;

import java.util.Stack;
import binary.AbstractBinaryTreeNode; // Assuming this class will exist for binary tree nodes

/**
 * Implements an in-order depth-first traversal iterator (LNR - Left, Node,
 * Right). This iterator is designed specifically for binary trees. [cite: 35]
 *
 * @param <N> The type of the binary tree node (must be an
 *            AbstractBinaryTreeNode or subclass).
 * @param <D> The type of the data stored in the tree node.
 */
public class DepthLNRTreeNodeIterator<N extends AbstractBinaryTreeNode<N, D>, D>
		extends AbstractArrayBasedTreeNodeIterator<N, D> {

	private final Stack<N> stack;
	/**
	 * Constructs a DepthLNRTreeNodeIterator starting from the specified root.
	 * 
	 * @param root The root node for the traversal.
	 */
	public DepthLNRTreeNodeIterator(N root) {
		super(root);
		this.stack = new Stack<>();
		// Initialize the stack to move to the leftmost node
		pushLeftmost(root);
	}

	private void pushLeftmost(N node) {
		while (node != null) {
			this.stack.push(node);
			node = node.getLeftChild();
		}
	}

	@Override
	public boolean hasNext() {
		return !this.stack.isEmpty();
	}

	@Override
	public N next() {
		if (!hasNext()) {
			throw new java.util.NoSuchElementException("No more nodes in the in-order traversal."); //$NON-NLS-1$
		}

		N node = this.stack.pop(); // This is the 'N' in LNR

		// After visiting the node, move to its right subtree
		if (node.getRightChild() != null) {
			pushLeftmost(node.getRightChild());
		}

		return node;
	}
}