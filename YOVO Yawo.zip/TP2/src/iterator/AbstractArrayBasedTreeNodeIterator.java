package iterator;

import model.TreeNode;
import java.util.Iterator;

/**
 * An abstract base class for tree node iterators that might rely on array-based
 * or collection-based internal structures for traversal.
 *
 * @param <N> The type of the tree node.
 * @param <D> The type of the data stored in the tree node.
 */
public abstract class AbstractArrayBasedTreeNodeIterator<N extends TreeNode<N, D>, D> implements Iterator<N> {

	protected N root; // The root node of the subtree being iterated [cite: 12]

	/**
	 * Constructs an iterator starting from the given root node.
	 * 
	 * @param root The root node from which to start the iteration.
	 */
	public AbstractArrayBasedTreeNodeIterator(N root) {
		this.root = root;
	}

	// The hasNext() and next() methods are abstract and must be implemented by
	// concrete iterators.
	@Override
	public abstract boolean hasNext();

	@Override
	public abstract N next();

	/**
	 * This operation is not supported by these iterators.
	 * 
	 * @throws UnsupportedOperationException always.
	 */
	@Override
	public void remove() {
		throw new UnsupportedOperationException("Remove operation is not supported by this iterator."); //$NON-NLS-1$
	}
}