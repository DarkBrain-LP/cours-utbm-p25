package iterator;

import model.TreeNode;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Implements a breadth-first traversal iterator for tree nodes. It returns
 * nodes level by level from the root to the leaves. [cite: 31]
 *
 * @param <N> The type of the tree node.
 * @param <D> The type of the data stored in the tree node.
 */
public class BreadthFirstTreeNodeIterator<N extends TreeNode<N, D>, D>
		extends AbstractArrayBasedTreeNodeIterator<N, D> {

	private final Queue<N> queue;

	/**
	 * Constructs a BreadthFirstTreeNodeIterator starting from the specified root.
	 * 
	 * @param root The root node for the traversal.
	 */
	public BreadthFirstTreeNodeIterator(N root) {
		super(root);
		this.queue = new LinkedList<>();
		if (root != null) {
			this.queue.offer(root); // Start with the root node
		}
	}

	@Override
	public boolean hasNext() {
		return !this.queue.isEmpty();
	}

	@Override
	public N next() {
		if (!hasNext()) {
			throw new java.util.NoSuchElementException("No more nodes in the breadth-first traversal."); //$NON-NLS-1$
		}
		N currentNode = this.queue.poll();
		if (currentNode != null) {
			for (N child : currentNode.getChildren()) {
				this.queue.offer(child); // Add all children to the queue
			}
		}
		return currentNode;
	}
}