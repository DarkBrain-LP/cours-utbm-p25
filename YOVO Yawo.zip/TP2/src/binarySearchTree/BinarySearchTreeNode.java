package binarySearchTree;


import factory.TreeNodeFactory;

import java.lang.ref.WeakReference;
import java.util.Comparator;

/**
 * A concrete implementation of a binary search tree node. This class uses a
 * comparator (or natural ordering) to determine the position of new data within
 * the tree.
 *
 * @param <D> The type of the data held within the node.
 */
public class BinarySearchTreeNode<D> extends AbstractBinarySearchTreeNode<BinarySearchTreeNode<D>, D> {

	/**
	 * Constructs a {@code BinarySearchTreeNode} with a specific factory. Assumes
	 * data type D implements Comparable<D> if no comparator is provided later.
	 *
	 * @param factory The factory responsible for creating instances of
	 *                {@code BinarySearchTreeNode}.
	 */
	public BinarySearchTreeNode(TreeNodeFactory<BinarySearchTreeNode<D>, D> factory) {
		super(factory);
	}

	/**
	 * Constructs a {@code BinarySearchTreeNode} with a specific factory and a
	 * custom comparator.
	 *
	 * @param factory    The factory responsible for creating instances of
	 *                   {@code BinarySearchTreeNode}.
	 * @param comparator The comparator to use for comparing data elements.
	 */
	public BinarySearchTreeNode(TreeNodeFactory<BinarySearchTreeNode<D>, D> factory, Comparator<D> comparator) {
		super(factory, comparator);
	}

	/**
	 * Inner class implementing the TreeNodeFactory for BinarySearchTreeNode. This
	 * factory creates instances of BinarySearchTreeNode.
	 * @param <D> The data type of the nodes
	 */
	public static class Factory<D> implements TreeNodeFactory<BinarySearchTreeNode<D>, D> {
		private Comparator<D> factoryComparator;

		/**
		 * default constructor
		 */
		public Factory() {
			this.factoryComparator = null;
		}

		/**
		 * @param comparator the comparator that will be used for data comparison
		 */
		public Factory(Comparator<D> comparator) {
			this.factoryComparator = comparator;
		}

		@Override
		public BinarySearchTreeNode<D> createRootNode() {
			// create the node without parent
			return new BinarySearchTreeNode<>(this, this.factoryComparator);
		}

		@Override
		public BinarySearchTreeNode<D> createNode(BinarySearchTreeNode<D> parent) { // N is a  BinarySearchTreeNode<D>
			// Create the node with the given parent
			var node = new BinarySearchTreeNode<>(this, this.factoryComparator);
			node.setParent(new WeakReference<>(parent)); // set parent via weak reference
			return node;
		}
	}

	/**
	 * Inserts data into the binary search tree rooted at this node. This method
	 * recursively finds the correct position for the new data based on the tree's
	 * ordering.
	 *
	 * @param data The data to insert.
	 * @return The node where the data was actually inserted.
	 */
	@Override
	public BinarySearchTreeNode<D> insertData(D data) {
		// If this node is empty, put the data here. This handles the initial insertion
		// when traversing down a path and finding a null child.
		if (getData().isEmpty()) {
			addData(data);
			return this;
		}

		// Get the "primary" data of this node for comparison.
		// Assuming a BST node holds one primary data element for comparison.
		// If dataStorage can hold multiple (e.g., for duplicate keys),
		// you'd need to define which one acts as the key.
		D existingData = getData().iterator().next(); // Assumes dataStorage is not empty

		int comparisonResult = compareData(data, existingData);

		if (comparisonResult < 0) { // New data is smaller, go left
			if (getLeftChild() == null) {
				// Create a new node and set it as the left child
				BinarySearchTreeNode<D> newNode = getFactory().createNode(this);
				newNode.addData(data);
				// Ensure the new node inherits the comparator from the factory/tree
				if (this.comparator != null && newNode.comparator == null) {
					newNode.setComparator(this.comparator);
				}
				setLeftChild(newNode); // Use the protected setter from AbstractBinaryTreeNode
				fireChildAdded(newNode, 0); // Notify listeners: 0 for left child
				return newNode;
			}
			// Recursively insert into the left subtree
			return getLeftChild().insertData(data);
		} else if (comparisonResult > 0) { // New data is larger, go right
			if (getRightChild() == null) {
				// Create a new node and set it as the right child
				BinarySearchTreeNode<D> newNode = getFactory().createNode(this);
				newNode.addData(data);
				// Ensure the new node inherits the comparator from the factory/tree
				if (this.comparator != null && newNode.comparator == null) {
					newNode.setComparator(this.comparator);
				}
				setRightChild(newNode); // Use the protected setter from AbstractBinaryTreeNode
				fireChildAdded(newNode, 1); // Notify listeners: 1 for right child
				return newNode;
			}
			// Recursively insert into the right subtree
			return getRightChild().insertData(data);
		} else {
			// Data is equal (duplicate).
			// Binary Search Trees can handle duplicates in various ways:
			// 1. Ignore the duplicate (return this node or null)
			// 2. Add it to the current node's dataStorage (if dataStorage allows multiple)
			// 3. Add it to the right subtree (common for non-unique keys)
			// 4. Throw an exception
			// For now, let's just add it to the current node if duplicates are allowed at
			// the same node.
			// Or you might want to consider putting it to the right subtree for strict
			// ordering.
			// Given the UML, it just has insertData, implying it handles the insertion
			// itself.
			System.out.println("Duplicate data '" + data + "' found at node '" + existingData //$NON-NLS-1$ //$NON-NLS-2$
					+ "'. Adding to current node dataStorage."); //$NON-NLS-1$
			addData(data); // Add to current node's dataStorage
			return this;
		}
	}
}