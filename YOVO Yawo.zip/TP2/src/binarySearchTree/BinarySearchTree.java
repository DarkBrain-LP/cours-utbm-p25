package binarySearchTree;

import java.util.Comparator;
import java.util.Iterator;
import binary.AbstractBinaryTree;
import iterator.BreadthFirstTreeNodeIterator; // Or your chosen default
import iterator.DataIterator;
import iterator.DepthNLRTreeNodeIterator;

/**
 * A concrete implementation of a binary search tree structure. This class uses
 * {@code BinarySearchTreeNode} for its nodes and maintains an ordering based on
 * a provided comparator or natural ordering.
 *
 * @param <D> The type of the data held within the nodes of the tree.
 */
public class BinarySearchTree<D> extends AbstractBinaryTree<BinarySearchTreeNode<D>, D> {

	private Comparator<D> treeComparator; // Store the comparator for the entire tree

	/**
	 * Constructs a {@code BinarySearchTree} that uses the natural ordering of its
	 * elements (data type D must implement {@code Comparable<D>}).
	 */
	public BinarySearchTree() {
		// Pass a factory that uses the default (null) comparator
		super(new BinarySearchTreeNode.Factory<>());
		this.treeComparator = null; // Indicates natural ordering
	}

	/**
	 * Constructs a {@code BinarySearchTree} with a custom comparator.
	 *
	 * @param comparator The comparator to use for ordering elements in the tree.
	 */
	public BinarySearchTree(Comparator<D> comparator) {
		// Pass a factory that uses the provided comparator
		super(new BinarySearchTreeNode.Factory<>(comparator));
		this.treeComparator = comparator;
	}

	/**
	 * Inserts data into the binary search tree. If the tree is empty, it creates
	 * the root. Otherwise, it delegates the insertion to the root node's
	 * {@code insertData} method, which will handle the recursive placement based on
	 * comparison.
	 *
	 * @param data The data to insert.
	 * @return The node where the data was actually inserted.
	 */
	@Override
	public BinarySearchTreeNode<D> insertData(D data) {
		if (getRoot() == null) {
			// If the tree is empty, create the root node using the factory
			BinarySearchTreeNode<D> newRoot = this.factory.createRootNode();
			newRoot.addData(data);
			// Ensure the root node knows its comparator
			newRoot.setComparator(this.treeComparator);
			setRoot(newRoot);
			return newRoot;
		}
		// Delegate insertion to the root node.
		// The root's insertData will recursively place the data.
		return getRoot().insertData(data);
	}

	/**
	 * Returns a default iterator over the nodes of the tree (e.g., level-order).
	 * You might choose an in-order iterator as the default for BSTs.
	 *
	 * @return An iterator for {@code BinarySearchTreeNode}s.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Iterator iterator() {
		// For BSTs, in-order (LNR) traversal is often the most natural default
		// as it produces sorted data.
		return new iterator.DepthLNRTreeNodeIterator<>(getRoot());
	}

	/**
	 * Returns an iterator over the data elements stored within the nodes of the
	 * tree. This iterator uses the default node traversal (e.g., in-order).
	 *
	 * @return An iterator for data elements of type {@code D}.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Iterator<D> dataIterator() {
		return new DataIterator<>(iterator()); // Uses the default node iterator (LNR)
	}
	
	// --- NOUVELLES MÉTHODES POUR LES ITÉRATEURS SPÉCIFIQUES ---

    /**
     * Returns an iterator over the nodes of the tree using Breadth-First (Level-Order) traversal.
     * @return An iterator for {@code BinarySearchTreeNode}s using Breadth-First traversal.
     */
    public Iterator<BinarySearchTreeNode<D>> getBreadthFirstNodeIterator() {
        return new BreadthFirstTreeNodeIterator<>(getRoot());
    }

    /**
     * Returns an iterator over the data elements of the tree using Breadth-First (Level-Order) traversal.
     * @return An iterator for data elements of type {@code D} using Breadth-First traversal.
     */
    public Iterator<D> getBreadthFirstDataIterator() {
        return new DataIterator<>(getBreadthFirstNodeIterator());
    }

    /**
     * Returns an iterator over the nodes of the tree using Pre-Order (NLR) depth-first traversal.
     * @return An iterator for {@code BinarySearchTreeNode}s using Pre-Order (NLR) traversal.
     */
    public Iterator<BinarySearchTreeNode<D>> getPreOrderNodeIterator() {
        return new DepthNLRTreeNodeIterator<>(getRoot());
    }

    /**
     * Returns an iterator over the data elements of the tree using Pre-Order (NLR) depth-first traversal.
     * @return An iterator for data elements of type {@code D} using Pre-Order (NLR) traversal.
     */
    public Iterator<D> getPreOrderDataIterator() {
        return new DataIterator<>(getPreOrderNodeIterator());
    }


	/**
	 * @param data the data we're looking for
	 * @return the node containing the data
	 * @note: it is an utility for testing
	 */
	public BinarySearchTreeNode<D> find(D data) {
		BinarySearchTreeNode<D> current = getRoot();
		while (current != null) {
			int cmp = current.compareData(data, current.getData().iterator().next());
			if (cmp == 0) {
				return current; // Found the node
			} else if (cmp < 0) {
				current = current.getLeftChild();
			} else {
				current = current.getRightChild();
			}
		}
		return null; // Not found
	}
}