package binarySearchTree;

import factory.TreeNodeFactory;
import java.util.Comparator; // Import for the comparator

import binary.AbstractBinaryTreeNode;

/**
 * An abstract base class for implementing binary search tree nodes. It extends
 * AbstractBinaryTreeNode and provides functionality for comparing data, which
 * is fundamental to binary search tree operations.
 *
 * @param <N> The concrete type of the binary search tree node, extending
 *            {@code AbstractBinarySearchTreeNode}.
 * @param <D> The type of the data held within the node. This type must be
 *            comparable, either naturally or via a provided Comparator.
 */
public abstract class AbstractBinarySearchTreeNode<N extends AbstractBinarySearchTreeNode<N, D>, D>
		extends AbstractBinaryTreeNode<N, D>{

	// A comparator to define the order of elements in the tree.
	// If null, natural ordering (Comparable) is assumed.
	protected Comparator<D> comparator;

	/**
	 * Constructs an {@code AbstractBinarySearchTreeNode} with a specific factory.
	 * Assumes data type D implements Comparable<D> if no comparator is provided
	 * later.
	 *
	 * @param factory The factory responsible for creating instances of the concrete
	 *                node type.
	 */
	public AbstractBinarySearchTreeNode(TreeNodeFactory<N, D> factory) {
		super(factory);
		this.comparator = null; // Default to natural ordering if D is Comparable
	}

	/**
	 * Constructs an {@code AbstractBinarySearchTreeNode} with a specific factory
	 * and a custom comparator.
	 *
	 * @param factory    The factory responsible for creating instances of the
	 *                   concrete node type.
	 * @param comparator The comparator to use for comparing data elements.
	 */
	public AbstractBinarySearchTreeNode(TreeNodeFactory<N, D> factory, Comparator<D> comparator) {
		super(factory);
		this.comparator = comparator;
	}

	/**
	 * Sets the comparator for this node. This is typically set during tree
	 * construction or when the root node is created.
	 *
	 * @param comparator The comparator to use for comparing data elements.
	 */
	public void setComparator(Comparator<D> comparator) {
		this.comparator = comparator;
	}

	/**
	 * Compares two data elements using the configured comparator or natural
	 * ordering.
	 *
	 * @param data1 The first data element.
	 * @param data2 The second data element.
	 * @return A negative integer, zero, or a positive integer as the first argument
	 *         is less than, equal to, or greater than the second.
	 * @throws ClassCastException   if the arguments' types prevent them from being
	 *                              compared by the comparator or natural ordering.
	 * @throws NullPointerException if a null comparator is used and the data is not
	 *                              naturally comparable (i.e., not an instance of
	 *                              Comparable).
	 */
	@SuppressWarnings("unchecked")
	protected int compareData(D data1, D data2) {
		if (this.comparator != null) {
			return this.comparator.compare(data1, data2);
		}
		// Assume D implements Comparable if no custom comparator is provided
		if (data1 instanceof Comparable) {
			return ((Comparable<D>) data1).compareTo(data2);
		}
		throw new IllegalStateException("Data type " + data1.getClass().getName() //$NON-NLS-1$
				+ " does not implement Comparable, and no Comparator was provided."); //$NON-NLS-1$
	}

	// insertData is still abstract here, as its full implementation depends on
	// how the concrete BinarySearchTreeNode handles actual data storage and
	// insertion.
	// The UML diagram shows `+ insertData(data: D) : N` for this abstract class.
	// However, the recursive nature of BST insertion often makes it a concrete
	// method
	// in the lowest concrete node class or the tree class itself.
	// For now, let's keep it abstract as per the diagram, and the concrete
	// BinarySearchTreeNode will implement it.
	@Override
	public abstract N insertData(D data); // Re-declare as abstract if it was abstract in AbstractTreeNode
}