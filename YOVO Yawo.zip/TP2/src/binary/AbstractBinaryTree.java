// In binary package
package binary;

import model.AbstractTree; // Extends AbstractTree from model package
import factory.TreeNodeFactory; // Assuming TreeNodeFactory is in 'factory' package

/**
 * An abstract base class for implementing binary trees. It extends
 * {@link AbstractTree} and works with {@link AbstractBinaryTreeNode}.
 *
 * @param <N> The concrete type of the binary tree node used by this tree.
 * @param <D> The type of the data held within the nodes of this tree.
 */
public abstract class AbstractBinaryTree<N extends AbstractBinaryTreeNode<N, D>, D> extends AbstractTree<N, D> {

	/**
	 * Constructs an {@code AbstractBinaryTree} with a specific node factory.
	 *
	 * @param factory The factory responsible for creating instances of the concrete
	 *                binary node type.
	 */
	public AbstractBinaryTree(TreeNodeFactory<N, D> factory) {
		super(factory);
	}

	// insertData and treeIterator are still abstract from AbstractTree, to be
	// implemented by concrete classes.
}