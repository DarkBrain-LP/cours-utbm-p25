// In binary package
package binary;

import model.AbstractTreeNode; // Extends AbstractTreeNode from model package
import factory.TreeNodeFactory; // Assuming TreeNodeFactory is in 'factory' package
import java.util.Collection;
import java.lang.ref.WeakReference;
import java.util.ArrayList; // For getChildren()
import java.util.Collections; // For unmodifiable list

/**
 * An abstract base class for implementing binary tree nodes. It extends
 * {@link AbstractTreeNode} and adds specific binary tree properties like left
 * and right children.
 *
 * @param <N> The concrete type of the binary tree node, extending
 *            {@code AbstractBinaryTreeNode}.
 * @param <D> The type of the data held within the node.
 */
public abstract class AbstractBinaryTreeNode<N extends AbstractBinaryTreeNode<N, D>, D> extends AbstractTreeNode<N, D> {

	protected N leftChild; // Left child node
	protected N rightChild; // Right child node

	/**
	 * Constructs an {@code AbstractBinaryTreeNode} with a specific factory.
	 *
	 * @param factory The factory responsible for creating instances of the concrete
	 *                node type.
	 */
	public AbstractBinaryTreeNode(TreeNodeFactory<N, D> factory) {
		super(factory);
		this.leftChild = null;
		this.rightChild = null;
	}

	/**
	 * Returns the left child of this node.
	 * 
	 * @return The left child node, or {@code null} if it does not exist.
	 */
	public N getLeftChild() {
		return this.leftChild;
	}

	/**
	 * Returns the right child of this node.
	 * 
	 * @return The right child node, or {@code null} if it does not exist.
	 */
	public N getRightChild() {
		return this.rightChild;
	}

	/**
	 * Gets the left child. If it does not exist and {@code createIfNone} is true, a
	 * new left child is created using the factory and set as the left child.
	 *
	 * @param createIfNone If true, create the left child if it's null.
	 * @return The left child.
	 */
	public N getLeftChild(boolean createIfNone) {
		if (this.leftChild == null && createIfNone) {
			N newNode = getFactory().createNode(this.self()); // Use factory to create
			this.setLeftChild(newNode);
			fireChildAdded(newNode, 0); // Notify observers
		}
		return this.leftChild;
	}

	/**
	 * Gets the right child. If it does not exist and {@code createIfNone} is true,
	 * a new right child is created using the factory and set as the right child.
	 *
	 * @param createIfNone If true, create the right child if it's null.
	 * @return The right child.
	 */
	public N getRightChild(boolean createIfNone) {
		if (this.rightChild == null && createIfNone) {
			N newNode = getFactory().createNode(this.self()); // Use factory to create
			this.setRightChild(newNode);
			fireChildAdded(newNode, 1); // Notify observers
		}
		return this.rightChild;
	}

	/**
	 * Sets the left child of this node.
	 * 
	 * @param leftChild The node to set as the left child.
	 */
	protected void setLeftChild(N leftChild) {
		this.leftChild = leftChild;
		if (leftChild != null) {
			leftChild.setParent(new WeakReference<>(this.self())); // Set parent reference for the child
		}
	}

	/**
	 * Sets the right child of this node.
	 * 
	 * @param rightChild The node to set as the right child.
	 */
	protected void setRightChild(N rightChild) {
		this.rightChild = rightChild;
		if (rightChild != null) {
			rightChild.setParent(new WeakReference<>(this.self())); // Set parent reference for the child
		}
	}

	@Override
	public Collection<N> getChildren() {
		Collection<N> children = new ArrayList<>(2);
		if (this.leftChild != null) {
			children.add(this.leftChild);
		}
		if (this.rightChild != null) {
			children.add(this.rightChild);
		}
		return Collections.unmodifiableCollection(children);
	}

	@Override
	public int getChildCount() {
		int count = 0;
		if (this.leftChild != null) {
			count++;
		}
		if (this.rightChild != null) {
			count++;
		}
		return count; // Returns 0, 1, or 2
	}

	/**
	 * Helper method to return 'this' as the concrete type N. This is safe because N
	 * extends AbstractBinaryTreeNode.
	 * 
	 * @return This node cast to type N.
	 */
	@SuppressWarnings("unchecked")
	protected N self() {
		return (N) this;
	}
}