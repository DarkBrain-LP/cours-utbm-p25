// In binary package
package binary;

import java.lang.ref.WeakReference;

import factory.TreeNodeFactory; // Assuming TreeNodeFactory is in 'factory' package

/**
 * A concrete implementation of a binary tree node.
 *
 * @param <D> The type of data stored in the node.
 */
public class BinaryTreeNode<D> extends AbstractBinaryTreeNode<BinaryTreeNode<D>, D> {

	/**
	 * Constructs a BinaryTreeNode with a specific factory. The factory is typically
	 * provided by the tree structure or a higher-level factory.
	 *
	 * @param factory The factory responsible for creating instances of
	 *                {@code BinaryTreeNode}.
	 */
	public BinaryTreeNode(TreeNodeFactory<BinaryTreeNode<D>, D> factory) {
		super(factory);
	}

	@Override
	public BinaryTreeNode<D> insertData(D data) {
		// Implementation of insertData for a generic Binary Tree.
		// This is a simple, non-ordered insertion. It will try to fill the current node
		// if empty, then left, then right.
		if (this.getData().isEmpty()) {
			this.addData(data); // Add data to this node
			return this;
		}
		// If this node already has data, try to insert into a child.
		// This simplistic approach will just fill the tree left-to-right on each level
		// before going deeper.
		// It won't maintain any specific ordering or balance.
		if (this.getLeftChild() == null
				|| this.getLeftChild().getChildCount() <= this.getRightChild().getChildCount()) {
			// Prioritize left child for insertion or if left is less full
			return this.getLeftChild(true).insertData(data);
		}
		// Otherwise, insert into the right child
		return this.getRightChild(true).insertData(data);
	}

	/**
	 * Inner static class implementing the {@link TreeNodeFactory} for
	 * {@code BinaryTreeNode}.
	 * @param <D> The nodes's data type
	 */
	public static class Factory<D> implements TreeNodeFactory<BinaryTreeNode<D>, D> {
		@Override
		public BinaryTreeNode<D> createRootNode() {
			// Pass 'this' factory instance to the new node
			return new BinaryTreeNode<>(this);
		}


		@Override
		public BinaryTreeNode<D> createNode(BinaryTreeNode<D> parent) {
//			 Pass 'this' factory instance to the new node
			// The parent argument is used to link the new node to its parent after
			// creation.
			var node = new BinaryTreeNode<>(this);
			node.setParent(new WeakReference<>(parent));
			return node;
		}
	}
}