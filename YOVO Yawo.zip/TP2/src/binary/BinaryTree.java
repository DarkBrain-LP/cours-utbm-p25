package binary;

import java.util.Iterator;

import iterator.DataIterator;

/**
 * A concrete implementation of a binary tree structure. This class uses
 * {@code BinaryTreeNode} for its nodes.
 *
 * @param <D> The type of the data held within the nodes of the tree.
 */
public class BinaryTree<D> extends AbstractBinaryTree<BinaryTreeNode<D>, D> {

	/**
	 * Constructs a {@code BinaryTree}. It creates a root node using the provided
	 * factory.
	 */
	public BinaryTree() {
		// Instantiate the BinaryTreeNodeFactory specific to BinaryTreeNode
		super(new BinaryTreeNode.Factory<>());
	}

	// You might add specific methods for BinaryTree here, such as
	// level-order traversal, or more specific insertion methods if the
	// tree needs to maintain certain properties (e.g., completeness, balance).

	/**
	 * Inserts data into the binary tree. This method typically delegates the actual
	 * insertion logic to the root node, or it can implement its own logic to find
	 * the appropriate insertion point. For a simple binary tree, if the root is
	 * null, it creates the root. Otherwise, it delegates to the root's insertData.
	 *
	 * @param data The data to insert.
	 * @return The node where the data was actually inserted.
	 */
	@Override
	public BinaryTreeNode<D> insertData(D data) {
		if (getRoot() == null) {
			// If the tree is empty, create the root node and add data to it.
			BinaryTreeNode<D> newRoot = this.factory.createRootNode();
			newRoot.addData(data);
			setRoot(newRoot);
			// No fireChildAdded here, as it's the root of the tree, not a child of another
			// node.
			// You might have a specific TreeEvent for root creation if needed.
			return newRoot;
		}
		// Delegate insertion to the root node's insertData method.
		// The logic in BinaryTreeNode.insertData will handle finding a spot.
		return getRoot().insertData(data);
	}

	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<D> dataIterator() {
		return new DataIterator<>(iterator()); // Pass the node iterator to the DataIterator
	}
}