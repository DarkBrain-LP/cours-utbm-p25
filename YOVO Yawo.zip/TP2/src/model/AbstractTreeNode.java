package model;

import java.util.Collection;
import factory.TreeNodeFactory;
import observer.TreeDataEvent;
import observer.TreeEvent;
import observer.TreeListener;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * An abstract base class for implementing the {@link TreeNode} interface. It
 * provides common functionality for managing data, listeners, and the parent
 * node.
 *
 * @param <N> The concrete type of the tree node, extending
 *            {@code AbstractTreeNode}.
 * @param <D> The type of the data held within the node.
 */
public abstract class AbstractTreeNode<N extends AbstractTreeNode<N, D>, D> implements TreeNode<N, D> {

	protected Collection<D> dataStorage;
	protected Collection<TreeListener> observers;
	//	protected N parent; // Use the concrete type here
	// private pour tous les attributs
	 private WeakReference<N> parent;
	protected final TreeNodeFactory<N, D> factory; // Factory to create new nodes

	/**
	 * Constructs an {@code AbstractTreeNode} with a specific factory. The Factory
	 * design pattern is used here to decouple the node creation from the node class
	 * itself.
	 *
	 * @param factory The factory responsible for creating instances of the concrete
	 *                node type.
	 */
	public AbstractTreeNode(TreeNodeFactory<N, D> factory) {
		this.factory = factory;
		this.dataStorage = new ArrayList<>(); // Using a concrete Collection
		this.observers = new ArrayList<>(); // Using a concrete Collection
		this.parent = null;
	}

	@Override
	public N getParent() {
		return this.parent.get();
	}

	/**
	 * Sets the parent of this node. This method is typically used internally when
	 * adding or removing child nodes.
	 *
	 * @param parent The new parent node.
	 */
	public void setParent(WeakReference<N> parent) {
		this.parent = parent;
	}

	@Override
	public boolean isRootNode() {
		return this.parent == null;
	}

	@Override
	public boolean isLeafNode() {
		return getChildren().isEmpty(); // Rely on the getChildren() implementation
	}

	@Override
	public abstract Collection<N> getChildren(); // Made abstract as the storage mechanism varies

	@Override
	public int getChildCount() {
		return getChildren().size();
	}

	@Override
	public Collection<D> getData() {
		return java.util.Collections.unmodifiableCollection(this.dataStorage);
	}

	@Override
	public void addData(D data) {
		this.dataStorage.add(data);
		fireDataAdded(data); // Notify listeners
	}

	@Override
	public void removeData(D data) {
		if (this.dataStorage.remove(data)) {
			fireDataRemoved(data); // Notify listeners
		}
	}

	@Override
	public abstract N insertData(D data); // Made abstract as insertion logic varies

	@Override
	public void addTreeListener(TreeListener observer) {
		this.observers.add(observer);
	}

	@Override
	public void removeTreeListener(TreeListener observer) {
		this.observers.remove(observer);
	}

	/**
	 * Gets the factory used to create new nodes of the concrete type. This follows
	 * the Factory Method design pattern.
	 *
	 * @return The node factory.
	 */
	protected TreeNodeFactory<N, D> getFactory() {
		return this.factory;
	}

	/**
	 * Notifies all registered listeners that a child node has been added.
	 *
	 * @param node  The newly added child node.
	 * @param index The index at which the child was added (if applicable).
	 */
	protected void fireChildAdded(N node, int index) {
		TreeEvent event = new TreeEvent(this, index, node);
		fireChildAdded(event);
	}

	/**
	 * Notifies all registered listeners that a child node has been added.
	 *
	 * @param event The event object describing the child addition.
	 */
	protected void fireChildAdded(TreeEvent event) {
		for (TreeListener listener : this.observers) {
			listener.childCreated(event);
		}
	}

	/**
	 * Notifies all registered listeners that data has been added to this node.
	 *
	 * @param data The data that was added.
	 */
	protected void fireDataAdded(D data) {
		TreeDataEvent event = new TreeDataEvent(this, data);
		fireDataAdded(event);
	}

	/**
	 * Notifies all registered listeners that data has been added to this node.
	 *
	 * @param event The event object describing the data addition.
	 */
	protected void fireDataAdded(TreeDataEvent event) {
		for (TreeListener listener : this.observers) {
			listener.dataAdded(event);
		}
	}

	/**
	 * Notifies all registered listeners that data has been removed from this node.
	 *
	 * @param data The data that was removed.
	 */
	protected void fireDataRemoved(D data) {
		TreeDataEvent event = new TreeDataEvent(this, data);
		fireDataRemoved(event);
	}

	/**
	 * Notifies all registered listeners that data has been removed from this node.
	 *
	 * @param event The event object describing the data removal.
	 */
	protected void fireDataRemoved(TreeDataEvent event) {
		for (TreeListener listener : this.observers) {
			listener.dataRemoved(event);
		}
	}
}