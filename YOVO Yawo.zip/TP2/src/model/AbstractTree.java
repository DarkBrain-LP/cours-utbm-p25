package model;

import factory.TreeNodeFactory;
import observer.TreeListener;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;

/**
 * An abstract base class for implementing the {@link Tree} interface. It
 * provides common functionality for managing the root node and listeners.
 *
 * @param <N> The concrete type of the tree node used by this tree.
 * @param <D> The type of the data held within the nodes of this tree.
 */
public abstract class AbstractTree<N extends AbstractTreeNode<N, D>, D> implements Tree<N, D> {
	protected N root;
	protected final TreeNodeFactory<N, D> factory; // Factory to create root node
	protected final Collection<TreeListener> observers;

	/**
	 * Constructs an {@code AbstractTree} with a specific node factory. The Factory
	 * design pattern is used here.
	 *
	 * @param factory The factory responsible for creating instances of the concrete
	 *                node type.
	 */
	public AbstractTree(TreeNodeFactory<N, D> factory) {
		this.factory = factory;
		this.root = null;
		this.observers = new ArrayList<>();
	}

	@Override
	public N getRoot() {
		return this.root;
	}

	/**
	 * Sets the root node of the tree. This is typically used internally when the
	 * first node is added to an empty tree.
	 *
	 * @param root The root node.
	 */
	protected void setRoot(N root) {
		this.root = root;
	}

	@Override
	public abstract N insertData(D data); // Made abstract as insertion logic varies

	@Override
	public abstract Iterator<D> dataIterator(); // Made abstract as traversal logic varies

	@Override
	public void addTreeListener(TreeListener observer) {
		this.observers.add(observer);
	}

	@Override
	public void removeTreeListener(TreeListener observer) {
		this.observers.remove(observer);
	}

//	 /**
//	 * Notifies all registered listeners that a new node has been added to the tree.
//	 *
//	 * @param node The newly added node.
//	 */
//	 protected void fireNodeAdded(N node) {
//		 TreeEvent event = new TreeEvent(this, node, TreeEventType.NODE_ADDED);
//		 for (TreeListener listener : observers) {
//		 listener.nodeAdded(event);
//		 }
//	 }
}
