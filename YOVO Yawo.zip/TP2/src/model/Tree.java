package model;

import java.util.Iterator;
import observer.TreeListener;

/**
 * Generic tree interface representing a tree data structure.
 * @param <N> The type of nodes in the tree
 * @param <D> The type of data stored in the nodes
 */
public interface Tree<N extends TreeNode<N, D>, D> extends Iterable<D> {
    /**
     * Gets the root node of the tree.
     * @return The root node
     */
    N getRoot();

    /**
     * Inserts data into the tree.
     * @param data The data to insert
     * @return The node where the data was inserted
     */
    N insertData(D data);

    /**
     * Creates an iterator to traverse the tree's data.
     * @return An iterator over the tree's data
     */
    Iterator<D> dataIterator();

    /**
     * Adds a tree listener to observe tree events.
     * @param observer The tree listener to add
     */
    void addTreeListener(TreeListener observer);

    /**
     * Removes a tree listener from the tree.
     * @param observer The tree listener to remove
     */
    void removeTreeListener(TreeListener observer);
}


