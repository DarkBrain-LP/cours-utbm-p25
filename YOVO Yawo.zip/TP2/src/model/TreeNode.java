package model;

import java.util.Collection;
import observer.TreeListener;


/**
 * Generic tree node interface representing nodes in a tree structure.
 * @param <N> The type of nodes
 * @param <D> The type of data stored in the nodes
 */
public interface TreeNode<N extends TreeNode<N, D>, D> {
    /**
     * Gets the parent node of the current node.
     * @return The parent node
     */
    public N getParent();
    
    /**
     * Checks if the node is the root of the tree.
     * @return true if the node is the root, false otherwise
     */
    boolean isRootNode();

    /**
     * Checks if the node is a leaf (has no children).
     * @return true if the node is a leaf, false otherwise
     */
    public boolean isLeafNode();

//    /**
//     * Gets the index of this node among its parent's children.
//     * @return The index of the node
//     */
//    int getIndex();

    /**
     * Gets a collection of child nodes.
     * @return Collection of child nodes
     */
    Collection<N> getChildren();

    /**
     * Gets the number of children for this node.
     * @return The count of child nodes
     */
    int getChildCount();

    /**
     * Gets the data stored in the node.
     * @return The node's data
     */
    Collection<D> getData();
    
    /**
     * Adds data to the node.
     * @param data The data to add
     */
    void addData(D data);

    /**
     * Removes specific data from the node.
     * @param data The data to remove
     */
    void removeData(D data);

    /**
     * Inserts data into the node or its subtree.
     * @param data The data to insert
     * @return the TreeNode element to whom the data is added
     */
    N insertData(D data);

    /**
     * Adds a tree event listener to the node.
     * @param observer The listener to add
     */
    void addTreeListener(TreeListener observer);

    /**
     * Removes a tree event listener from the node.
     * @param observer The listener to remove
     */
    void removeTreeListener(TreeListener observer);
}
