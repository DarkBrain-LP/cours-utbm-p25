package observer;

/**
 * Enumeration of tree-related event types.
 */
public enum TreeEventType {
    /**
     * Event type for data addition.
     */
    DATA_ADDED,

    /**
     * Event type for data removal.
     */
    DATA_REMOVED,

    /**
     * Event type for child node creation.
     */
    CHILD_ADDED,

    /**
     * Event type for node addition to the tree.
     */
    NODE_ADDED
}