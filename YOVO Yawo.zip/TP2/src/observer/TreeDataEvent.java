package observer;

import java.util.EventObject;

/**
 * Event object for data-related tree events.
 */
public class TreeDataEvent extends EventObject {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * The data associated with the event.
     */
    private Object data;

    /**
     * Constructs a new TreeDataEvent.
     * @param source The source of the event
     * @param data The data associated with the event
     */
    public TreeDataEvent(Object source, Object data) {
        super(source);
        this.data = data;
    }

    /**
     * Gets the data associated with the event.
     * @return The event's data
     */
    public Object getData() {
        return this.data;
    }
}