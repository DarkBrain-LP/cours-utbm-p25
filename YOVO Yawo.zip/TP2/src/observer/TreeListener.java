package observer;

import java.util.EventListener;

/**
 * Listener interface for tree-related events.
 */
public interface TreeListener extends EventListener {
    /**
     * Called when data is added to a tree or node.
     * @param event The data addition event
     */
    void dataAdded(TreeDataEvent event);

    /**
     * Called when data is removed from a tree or node.
     * @param event The data removal event
     */
    void dataRemoved(TreeDataEvent event);

    /**
     * Called when a child is created in a tree or node.
     * @param event The child creation event
     */
    void childCreated(TreeEvent event);
}