package observer;

import java.util.EventObject;

import model.TreeNode;

/**
 * Base event object for tree-related events.
 */
public class TreeEvent extends EventObject {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * The node associated with the event.
     */
    private TreeNode<?, ?> node;

    /**
     * The index associated with the event.
     */
    private int index;

    /**
     * Constructs a new TreeEvent.
     * @param source The source of the event
     * @param index The index associated with the event
     * @param node The node associated with the event
     */
    public TreeEvent(Object source, int index, TreeNode<?, ?> node) {
        super(source);
        this.index = index;
        this.node = node;
    }

    /**
     * Gets the node associated with the event.
     * @return The event's node
     */
    public TreeNode<?, ?> getNode() {
        return this.node;
    }

    /**
     * Gets the index associated with the event.
     * @return The event's index
     */
    public int getIndex() {
        return this.index;
    }
}