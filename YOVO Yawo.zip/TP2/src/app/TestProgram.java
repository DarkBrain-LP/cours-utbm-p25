// app/TestProgram.java (MODIFIED)

package app;

import binarySearchTree.BinarySearchTree;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * Class responsible for testing the whole code of the TP
 */
public class TestProgram {

    /**
     * Test Binary Search Tree with static numbers for checking insertion and iteration
     */
    @SuppressWarnings("boxing")
	public static void testBinarySearchTree() {
        System.out.println("--- Démarrage du test du Binary Search Tree ---"); //$NON-NLS-1$

        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        System.out.println("\n1. Arbre binaire de recherche d'entiers créé."); //$NON-NLS-1$

        Integer[] staticNumbers = {50, 30, 70, 20, 40, 60, 80, 10, 35, 45, 55, 65, 75, 85, 90};

        System.out.println("\n2. Ajout des entiers statiques à l'arbre :"); //$NON-NLS-1$
        System.out.print("Nombres à ajouter : "); //$NON-NLS-1$
        for (int number : staticNumbers) {
            System.out.print(number + " "); //$NON-NLS-1$
            bst.insertData(Integer.valueOf(number));
        }
        System.out.println("\nEntiers statiques ajoutés."); //$NON-NLS-1$

        System.out.println("\n3. Affichage de la liste triée des entiers (parcours In-Order LNR) :"); //$NON-NLS-1$
        Iterator<Integer> sortedIterator = bst.dataIterator(); // Utilise la valeur par défaut (LNR)

        System.out.print("Éléments triés obtenus : "); //$NON-NLS-1$
        while (sortedIterator.hasNext()) {
            System.out.print(sortedIterator.next() + " "); //$NON-NLS-1$
        }
        System.out.println();

        Arrays.sort(staticNumbers);
        System.out.print("Ordre trié attendu (de Arrays.sort) : "); //$NON-NLS-1$
        for (int number : staticNumbers) {
            System.out.print(number + " "); //$NON-NLS-1$
        }
        System.out.println();
        
        Integer[] expectedSortedNumbers = Arrays.copyOf(staticNumbers, staticNumbers.length);
        Arrays.sort(expectedSortedNumbers);
        List<Integer> actualSortedList = getElementsFromIterator(bst.dataIterator());
        // Convertir Arrays.asList() en une nouvelle ArrayList pour s'assurer du type concret
        List<Integer> expectedSortedList = new ArrayList<>(Arrays.asList(expectedSortedNumbers)); // Clé de la correction

        System.out.println("Order obtained matches expected order : " + actualSortedList.equals(expectedSortedList)); //$NON-NLS-1$

        System.out.println("\n--- Fin du test du Binary Search Tree ---"); //$NON-NLS-1$
    }

    /**
     * Exécute un test complet sur un Binary Search Tree, incluant:
     * - Insertion d'un grand nombre d'éléments aléatoires.
     * - Vérification de l'ordre trié via l'itérateur LNR.
     * - Recherche de quelques éléments spécifiques pour vérifier la méthode find.
     * - **Nouveau : Affichage des parcours Breadth-First et Pre-Order.**
     */
    public static void comprehensiveBSTTest() {
        System.out.println("\n--- Démarrage du test complet du Binary Search Tree ---"); //$NON-NLS-1$

        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        System.out.println("\n1. Arbre binaire de recherche d'entiers créé."); //$NON-NLS-1$

        int numberOfRandomElements = 15; 
        List<Integer> insertedElements = new ArrayList<>();
        Random random = new Random();

        System.out.println("\n2. Ajout de " + numberOfRandomElements + " entiers aléatoires à l'arbre :"); //$NON-NLS-1$ //$NON-NLS-2$
        System.out.print("Nombres ajoutés : "); //$NON-NLS-1$
        for (int i = 0; i < numberOfRandomElements; i++) {
            int randomNumber = random.nextInt(100); 
            System.out.print(randomNumber + " "); //$NON-NLS-1$
            bst.insertData(Integer.valueOf(randomNumber));
            insertedElements.add(Integer.valueOf(randomNumber));
        }
        System.out.println("\nEntiers aléatoires ajoutés."); //$NON-NLS-1$

        
        System.out.println("\n3. Affichage des différents types de parcours :"); //$NON-NLS-1$

        
        System.out.print("  Parcours In-Order (LNR - Sorted) : "); //$NON-NLS-1$
        displayIteratorElements(bst.dataIterator());
        Collections.sort(insertedElements);
        System.out.print("  Ordre trié attendu : " + insertedElements); //$NON-NLS-1$
        System.out.println();


        //  Breadth-First (Level-Order)
        System.out.print("  Parcours Breadth-First (Level-Order) : "); //$NON-NLS-1$
        displayIteratorElements(bst.getBreadthFirstDataIterator());

        // Parcours Pre-Order (NLR)
        System.out.print("  Parcours Pre-Order (NLR) : "); //$NON-NLS-1$
        displayIteratorElements(bst.getPreOrderDataIterator());


        // 4. 
        System.out.println("\n4. Vérification de l'ordre In-Order :"); //$NON-NLS-1$
        List<Integer> actualSortedElements = getElementsFromIterator(bst.dataIterator());
        boolean orderMatches = actualSortedElements.equals(insertedElements); // insertedElements is already sorted
        System.out.println("  L'ordre In-Order obtenu correspond à l'ordre attendu : " + orderMatches); //$NON-NLS-1$
        if (!orderMatches) {
            System.err.println("  ERREUR: L'ordre des éléments In-Order ne correspond pas !"); //$NON-NLS-1$
        }

        // 5. 
        System.out.println("\n5. Test de la recherche d'éléments (find) :"); //$NON-NLS-1$
        // Make sure not IndexOutOfBoundsException
        if (!insertedElements.isEmpty()) {
            Integer searchElement1 = insertedElements.get(insertedElements.size() / 2); // middle item
            Integer searchElement2 = Integer.valueOf(-1); // 
            Integer searchElement3 = insertedElements.get(0); // the smaller'st

            System.out.println("  Recherche de l'élément " + searchElement1 + " : " + (bst.find(searchElement1) != null ? "Trouvé" : "Non trouvé")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            System.out.println("  Recherche de l'élément " + searchElement2 + " : " + (bst.find(searchElement2) != null ? "Trouvé" : "Non trouvé")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            System.out.println("  Recherche de l'élément " + searchElement3 + " : " + (bst.find(searchElement3) != null ? "Trouvé" : "Non trouvé")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

            boolean findTestPassed = true;
            if (bst.find(searchElement1) == null) {
                System.err.println("  ERREUR: L'élément " + searchElement1 + " aurait dû être trouvé !"); //$NON-NLS-1$ //$NON-NLS-2$
                findTestPassed = false;
            }
            if (bst.find(searchElement2) != null) {
                System.err.println("  ERREUR: L'élément " + searchElement2 + " n'aurait pas dû être trouvé !"); //$NON-NLS-1$ //$NON-NLS-2$
                findTestPassed = false;
            }
            if (bst.find(searchElement3) == null) {
                System.err.println("  ERREUR: L'élément " + searchElement3 + " aurait dû être trouvé !"); //$NON-NLS-1$ //$NON-NLS-2$
                findTestPassed = false;
            }
            System.out.println("  Test de la méthode find : " + (findTestPassed ? "SUCCÈS" : "ÉCHEC")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        } else {
            System.out.println("  Aucun élément inséré, test de find ignoré."); //$NON-NLS-1$
        }


        System.out.println("\n--- Fin du test complet du Binary Search Tree ---"); //$NON-NLS-1$
    }

    /**
     * Helper method to display elements from an iterator.
     */
    private static <T> void displayIteratorElements(Iterator<T> iterator) {
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " "); //$NON-NLS-1$
        }
        System.out.println();
    }

    /**
     * Helper method to get all elements from an iterator into a List.
     */
    private static <T> List<T> getElementsFromIterator(Iterator<T> iterator) {
        List<T> elements = new ArrayList<>();
        while (iterator.hasNext()) {
            elements.add(iterator.next());
        }
        return elements;
    }


    /**
     * main function
     * @param args
     */
    public static void main(String[] args) {
        testBinarySearchTree();


        comprehensiveBSTTest();
    }
}