package factory;

import model.TreeNode;

/**
 * Factory interface for creating tree nodes.
 * @param <N> The type of nodes
 * @param <D> The type of data stored in the nodes
 */
public interface TreeNodeFactory<N extends TreeNode<N, D>, D> {
    /**
     * Creates a root node for the tree.
     * @return A new root node
     */
    N createRootNode();

    /**
     * Creates a new node with a specified parent.
     * @param parent The parent node for the new node
     * @return A new node
     */
    N createNode(N parent);
}
