// GraphFactory.java
package factory;

import model.GraphEdge;
import model.GraphNode;

/**
 * Interface for a factory that creates graph elements (nodes and edges).
 * This is part of the Factory pattern implementation, allowing for
 * decoupled creation of graph components.
 *
 * @param <N> The type of nodes this factory creates.
 * @param <E> The type of edges this factory creates.
 * @param <D> The type of data associated with graph elements.
 */
public interface GraphFactory<N extends GraphNode<N, E, D>, E extends GraphEdge<N, E, D>, D> {

    /**
     * Creates a new graph node with the given name.
     * @param name The name of the node.
     * @return A new instance of a graph node of type N.
     */
    N createNode(String name);

    /**
     * Creates a new graph edge connecting two specified nodes.
     * @param name The name of the edge.
     * @param startNode The starting node of the edge.
     * @param endNode The ending node of the edge.
     * @return A new instance of a graph edge of type E.
     */
    E createEdge(String name, N startNode, N endNode);
}