package arraylistgraph;

import model.AbstractGraph;
import observer.GraphDataEvent;
import java.util.*;

import factory.GraphFactory;

/**
 * Graph implementation using ArrayLists and Maps.
 *
 * @param <D> The data type stored in the graph.
 */
public class ArrayListGraph<D>
        extends AbstractGraph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> {

    private final Map<String, ArrayListGraphNode<D>> nodes;
    private final Map<String, ArrayListGraphEdge<D>> edges;
    private final ArrayListGraphFactory<D> factory;

    /**
     * constructor
     */
    public ArrayListGraph() {
        this.nodes = new HashMap<>();
        this.edges = new HashMap<>();
        this.factory = new ArrayListGraphFactory<>(this);
    }

    @Override
    public GraphFactory<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> getFactory() {
        return this.factory;
    }

    @Override
    public Collection<ArrayListGraphNode<D>> getNodes() {
        return Collections.unmodifiableCollection(this.nodes.values());
    }

    @Override
    public Collection<ArrayListGraphEdge<D>> getEdges() {
        return Collections.unmodifiableCollection(this.edges.values());
    }

    @Override
    public ArrayListGraphNode<D> addNode(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Invalid node name"); //$NON-NLS-1$
        }
        if (this.nodes.containsKey(name)) {
            throw new IllegalArgumentException("Node already exists: " + name); //$NON-NLS-1$
        }

        ArrayListGraphNode<D> node = this.factory.createNode(name);
        this.nodes.put(name, node);
        fireGraphEvent(new GraphDataEvent(this, node));
        return node;
    }

    @Override
    public void addNode(ArrayListGraphNode<D> node) {
        if (node == null) {
            throw new IllegalArgumentException("Node is null"); //$NON-NLS-1$
        }
        if (this.nodes.containsKey(node.getName())) {
            throw new IllegalArgumentException("Duplicate node"); //$NON-NLS-1$
        }

        node.setParentGraph(this);
        this.nodes.put(node.getName(), node);
        fireGraphEvent(new GraphDataEvent(this, node));
    }

    @Override
    public ArrayListGraphEdge<D> addEdge(String name, ArrayListGraphNode<D> start, ArrayListGraphNode<D> end) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Edge name missing"); //$NON-NLS-1$
        }
        if (this.edges.containsKey(name)) {
            throw new IllegalArgumentException("Edge already exists: " + name); //$NON-NLS-1$
        }
        if (!this.nodes.containsValue(start) || !this.nodes.containsValue(end)) {
            throw new IllegalArgumentException("Nodes must be part of the graph"); //$NON-NLS-1$
        }

        ArrayListGraphEdge<D> edge = this.factory.createEdge(name, start, end);
        this.edges.put(name, edge);
        edge.setParentGraph(this);
        fireGraphEvent(new GraphDataEvent(this, edge));
        return edge;
    }

    @Override
    public void addEdge(ArrayListGraphEdge<D> edge, ArrayListGraphNode<D> start, ArrayListGraphNode<D> end) {
        if (edge == null) {
            throw new IllegalArgumentException("Edge is null"); //$NON-NLS-1$
        }
        if (this.edges.containsKey(edge.getName())) {
            throw new IllegalArgumentException("Duplicate edge"); //$NON-NLS-1$
        }
        if (!this.nodes.containsValue(start) || !this.nodes.containsValue(end)) {
            throw new IllegalArgumentException("Start/end not found"); //$NON-NLS-1$
        }
        if (edge.getStartingNode() != start || edge.getEndingNode() != end) {
            throw new IllegalArgumentException("Mismatched edge endpoints"); //$NON-NLS-1$
        }

        edge.setParentGraph(this);
        this.edges.put(edge.getName(), edge);
        fireGraphEvent(new GraphDataEvent(this, edge));
    }

    @Override
    public Iterator<D> iterator() {
        return new Iterator<>() {
            private final Iterator<ArrayListGraphNode<D>> nodeIt = ArrayListGraph.this.nodes.values().iterator();
            private final Iterator<ArrayListGraphEdge<D>> edgeIt = ArrayListGraph.this.edges.values().iterator();
            private Iterator<D> currentData = null;

            private void updateIterator() {
                if (this.currentData != null && this.currentData.hasNext()) return;

                while (this.nodeIt.hasNext()) {
                    this.currentData = this.nodeIt.next().getData().iterator();
                    if (this.currentData.hasNext()) return;
                }

                while (this.edgeIt.hasNext()) {
                    this.currentData = this.edgeIt.next().getData().iterator();
                    if (this.currentData.hasNext()) return;
                }

                this.currentData = null;
            }

            @Override
            public boolean hasNext() {
                updateIterator();
                return this.currentData != null && this.currentData.hasNext();
            }

            @Override
            public D next() {
                updateIterator();
                if (this.currentData == null || !this.currentData.hasNext()) {
                    throw new NoSuchElementException();
                }
                return this.currentData.next();
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException("Remove not supported"); //$NON-NLS-1$
            }
        };
    }

    @Override
    public Iterator<D> dataIterator() {
        return null; // left unimplemented
    }
}
