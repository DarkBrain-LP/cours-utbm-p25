package arraylistgraph;

import model.AbstractGraphEdge;
import model.Graph;

/**
 * Represents an edge between two nodes.
 *
 * @param <D> Data type stored in the edge.
 */
public class ArrayListGraphEdge<D>
        extends AbstractGraphEdge<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> {

    private Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph;

    /**
     * @param name
     * @param startNode
     * @param endNode
     */
    public ArrayListGraphEdge(String name, ArrayListGraphNode<D> startNode, ArrayListGraphNode<D> endNode) {
        super(name, startNode, endNode);

        // connect this edge to the nodes
        if (startNode != null) {
            startNode.connectStartingEdge(this);
        }
        if (endNode != null) {
            endNode.connectFinishingEdge(this);
        }
    }

    /**
     * @param name
     * @param startNode
     * @param endNode
     * @param parentGraph
     */
    public ArrayListGraphEdge(String name, ArrayListGraphNode<D> startNode, ArrayListGraphNode<D> endNode,
                              Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph) {
        super(name, startNode, endNode);
        this.parentGraph = parentGraph;

        if (startNode != null) {
            startNode.connectStartingEdge(this);
        }
        if (endNode != null) {
            endNode.connectFinishingEdge(this);
        }
    }

    /**
     * @param parentGraph 
     */
    public void setParentGraph(Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph) {
        this.parentGraph = parentGraph;
    }

    @Override
    public Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> getGraph() {
        return this.parentGraph;
    }
}
