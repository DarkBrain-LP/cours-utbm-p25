package arraylistgraph;

import model.AbstractGraphNode;
import model.Graph;

/**
 * A concrete implementation of a graph node, using ArrayLists for managing connected edges.
 *
 * @param <D> The type of data stored within this node.
 */
public class ArrayListGraphNode<D>
        extends AbstractGraphNode<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> {

    private Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph;

    /**
     * Constructs an ArrayListGraphNode with the given name.
     * @param name The name of the node.
     */
    public ArrayListGraphNode(String name) {
        super(name);
    }

    /**
     * Constructs an ArrayListGraphNode with the given name and parent graph.
     * @param name The name of the node.
     * @param parentGraph The graph this node belongs to.
     */
    public ArrayListGraphNode(String name, Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph) {
        super(name);
        this.parentGraph = parentGraph;
    }

    /**
     * Sets the parent graph for this node.
     * @param parentGraph The graph this node belongs to.
     */
    public void setParentGraph(Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph) {
        this.parentGraph = parentGraph;
    }

    @Override
    public Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> getGraph() {
        return this.parentGraph;
    }
}