package arraylistgraph;

import factory.GraphFactory;
import model.Graph;

/**
 * Factory class for making nodes and edges for ArrayListGraph.
 * @param <D> 
 */
public class ArrayListGraphFactory<D>
        implements GraphFactory<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> {

    private final Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph;

    /**
     * @param parentGraph
     */
    public ArrayListGraphFactory(Graph<ArrayListGraphNode<D>, ArrayListGraphEdge<D>, D> parentGraph) {
        this.parentGraph = parentGraph;
    }

    @Override
    public ArrayListGraphNode<D> createNode(String name) {
        return new ArrayListGraphNode<>(name, this.parentGraph);
    }

    @Override
    public ArrayListGraphEdge<D> createEdge(String name, ArrayListGraphNode<D> startNode, ArrayListGraphNode<D> endNode) {
        return new ArrayListGraphEdge<>(name, startNode, endNode, this.parentGraph);
    }
}
