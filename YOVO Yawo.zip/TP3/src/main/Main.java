package main;

import arraylistgraph.ArrayListGraph;
import arraylistgraph.ArrayListGraphEdge; 
import arraylistgraph.ArrayListGraphNode; 
import model.GraphNode;
import observer.GraphDataEvent;
import observer.GraphListener;
import model.Graph;
import iterator.GraphNodeIterator; 
import java.util.Random;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator; 
import java.util.NoSuchElementException;

/**
 * A test program to demonstrate the functionality of the graph library.
 * This class contains the main method as specified in Part G.
 */
public class Main {
	
	
	 /**
	 * cycling test
	 */
	@SuppressWarnings("boxing")
	public static void testCycling() {
	        System.out.println("\n--- Testing Cycling Behavior (Part G) ---"); //$NON-NLS-1$

	        // Create a new graph for this specific test
	        Graph<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> cycleGraph =
	                new ArrayListGraph<>();
	        System.out.println("Created a new graph for cycle test."); //$NON-NLS-1$

	        // Create nodes for a simple cycle: A -> B -> C -> A
	        ArrayListGraphNode<Integer> nodeA = cycleGraph.addNode("CycleNodeA"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> nodeB = cycleGraph.addNode("CycleNodeB"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> nodeC = cycleGraph.addNode("CycleNodeC"); //$NON-NLS-1$

	        // Add edges to form a cycle
	        cycleGraph.addEdge("EdgeAB_Cycle", nodeA, nodeB); //$NON-NLS-1$
	        cycleGraph.addEdge("EdgeBC_Cycle", nodeB, nodeC); //$NON-NLS-1$
	        cycleGraph.addEdge("EdgeCA_Cycle", nodeC, nodeA); //$NON-NLS-1$
	        System.out.println("Created nodes and edges for cycle: A -> B -> C -> A"); //$NON-NLS-1$

	        // Add some dummy data to nodes (optional for this test, but good practice)
	        nodeA.addData(10);
	        nodeB.addData(20);
	        nodeC.addData(30);

	        // Display nodes using GraphNodeIterator with enableCycles = true
	        // As per the revised iterator logic, it should still yield each node uniquely and terminate.
	        System.out.println("\nIterating over cycle graph nodes (enableCycles = true):"); //$NON-NLS-1$
	        // Directly instantiate GraphNodeIterator
	        Iterator<ArrayListGraphNode<Integer>> cycleIterator = new GraphNodeIterator<>(cycleGraph, true);

	        int count = 0;
	        while (cycleIterator.hasNext()) {
	            GraphNode<?, ?, Integer> node = cycleIterator.next();
	            System.out.println("  Visited Node: " + node.getName() + ", Data: " + node.getData()); //$NON-NLS-1$ //$NON-NLS-2$
	            count++;
	        }
	        System.out.println("Total nodes visited in cycle test: " + count); //$NON-NLS-1$

	        // Expected output: Each node A, B, C should be visited exactly once,
	        // and the total count should be 3, demonstrating termination and uniqueness
	        // in the presence of cycles as required.

	        System.out.println("--- Cycling Test Finished ---"); //$NON-NLS-1$
	    }
	 
	 /**
	 * verification function to ensure code is correct
	 */
	@SuppressWarnings({ "boxing", "unused" })
	public static void runVerificationTests() {
	        System.out.println("\n--- Running Automated Verification Tests ---"); //$NON-NLS-1$

	        // Test Case 1: Simple Graph - Node Iteration (no cycles)
	        System.out.println("\nTest Case 1: Node Iterator on simple acyclic graph (enableCycles=false)"); //$NON-NLS-1$
	        Graph<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> simpleGraph = new ArrayListGraph<>();
	        ArrayListGraphNode<Integer> n1 = simpleGraph.addNode("N1"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> n2 = simpleGraph.addNode("N2"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> n3 = simpleGraph.addNode("N3"); //$NON-NLS-1$
	        simpleGraph.addEdge("E12", n1, n2); //$NON-NLS-1$
	        simpleGraph.addEdge("E23", n2, n3); //$NON-NLS-1$

	        Set<String> visitedNodeNames = new HashSet<>();
	        Iterator<ArrayListGraphNode<Integer>> iter1 = new GraphNodeIterator<>(simpleGraph, false);
	        int count1 = 0;
	        try {
	            while (iter1.hasNext()) {
	                ArrayListGraphNode<Integer> node = iter1.next();
	                if (visitedNodeNames.contains(node.getName())) {
	                    System.err.println("  FAIL: Duplicate node '" + node.getName() + "' returned by iterator (Test 1)."); //$NON-NLS-1$ //$NON-NLS-2$
	                    return; // Fail fast
	                }
	                visitedNodeNames.add(node.getName());
	                count1++;
	            }
	            if (count1 == simpleGraph.getNodes().size()) {
	                System.out.println("  PASS: Node iterator (no cycles) visited " + count1 + " unique nodes. Terminated successfully."); //$NON-NLS-1$ //$NON-NLS-2$
	            } else {
	                System.err.println("  FAIL: Node iterator (no cycles) expected " + simpleGraph.getNodes().size() + " nodes, got " + count1 + " (Test 1)."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	            }
	        } catch (NoSuchElementException e) {
	            System.err.println("  FAIL: Node iterator (no cycles) threw NoSuchElementException prematurely (Test 1)."); //$NON-NLS-1$
	        } catch (Exception e) {
	            System.err.println("  FAIL: Node iterator (no cycles) encountered unexpected exception: " + e.getMessage() + " (Test 1)."); //$NON-NLS-1$ //$NON-NLS-2$
	        }


	        // Test Case 2: Cyclic Graph - Node Iteration (enableCycles=true)
	        System.out.println("\nTest Case 2: Node Iterator on cyclic graph (enableCycles=true)"); //$NON-NLS-1$
	        Graph<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> cyclicGraph = new ArrayListGraph<>();
	        ArrayListGraphNode<Integer> c1 = cyclicGraph.addNode("C1"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> c2 = cyclicGraph.addNode("C2"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> c3 = cyclicGraph.addNode("C3"); //$NON-NLS-1$
	        cyclicGraph.addEdge("C12", c1, c2); //$NON-NLS-1$
	        cyclicGraph.addEdge("C23", c2, c3); //$NON-NLS-1$
	        cyclicGraph.addEdge("C31", c3, c1); // Cycle //$NON-NLS-1$

	        visitedNodeNames.clear(); // Reset for new test
	        Iterator<ArrayListGraphNode<Integer>> iter2 = new GraphNodeIterator<>(cyclicGraph, true);
	        int count2 = 0;
	        try {
	            while (iter2.hasNext()) {
	                ArrayListGraphNode<Integer> node = iter2.next();
	                if (visitedNodeNames.contains(node.getName())) {
	                    System.err.println("  FAIL: Duplicate node '" + node.getName() + "' returned by iterator (Test 2)."); //$NON-NLS-1$ //$NON-NLS-2$
	                    return;
	                }
	                visitedNodeNames.add(node.getName());
	                count2++;
	            }
	            if (count2 == cyclicGraph.getNodes().size()) {
	                System.out.println("  PASS: Node iterator (with cycles) visited " + count2 + " unique nodes. Terminated successfully."); //$NON-NLS-1$ //$NON-NLS-2$
	            } else {
	                System.err.println("  FAIL: Node iterator (with cycles) expected " + cyclicGraph.getNodes().size() + " nodes, got " + count2 + " (Test 2)."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	            }
	        } catch (NoSuchElementException e) {
	            System.err.println("  FAIL: Node iterator (with cycles) threw NoSuchElementException prematurely (Test 2)."); //$NON-NLS-1$
	        } catch (Exception e) {
	            System.err.println("  FAIL: Node iterator (with cycles) encountered unexpected exception: " + e.getMessage() + " (Test 2)."); //$NON-NLS-1$ //$NON-NLS-2$
	        }

	        // Test Case 3: Disconnected Graph - Node Iteration
	        System.out.println("\nTest Case 3: Node Iterator on disconnected graph"); //$NON-NLS-1$
	        Graph<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> disconnectedGraph = new ArrayListGraph<>();
	        ArrayListGraphNode<Integer> d1 = disconnectedGraph.addNode("D1"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> d2 = disconnectedGraph.addNode("D2"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> d3 = disconnectedGraph.addNode("D3"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> d4 = disconnectedGraph.addNode("D4"); //$NON-NLS-1$
	        disconnectedGraph.addEdge("D12", d1, d2); // D1-D2 connected //$NON-NLS-1$
	        // D3, D4 are isolated nodes

	        visitedNodeNames.clear();
	        Iterator<ArrayListGraphNode<Integer>> iter3 = new GraphNodeIterator<>(disconnectedGraph, false); // Cycles false
	        int count3 = 0;
	        try {
	            while (iter3.hasNext()) {
	                ArrayListGraphNode<Integer> node = iter3.next();
	                if (visitedNodeNames.contains(node.getName())) {
	                    System.err.println("  FAIL: Duplicate node '" + node.getName() + "' returned by iterator (Test 3)."); //$NON-NLS-1$ //$NON-NLS-2$
	                    return;
	                }
	                visitedNodeNames.add(node.getName());
	                count3++;
	            }
	            if (count3 == disconnectedGraph.getNodes().size()) {
	                System.out.println("  PASS: Node iterator (disconnected) visited " + count3 + " unique nodes. Terminated successfully."); //$NON-NLS-1$ //$NON-NLS-2$
	            } else {
	                System.err.println("  FAIL: Node iterator (disconnected) expected " + disconnectedGraph.getNodes().size() + " nodes, got " + count3 + " (Test 3)."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	            }
	        } catch (NoSuchElementException e) {
	            System.err.println("  FAIL: Node iterator (disconnected) threw NoSuchElementException prematurely (Test 3)."); //$NON-NLS-1$
	        } catch (Exception e) {
	            System.err.println("  FAIL: Node iterator (disconnected) encountered unexpected exception: " + e.getMessage() + " (Test 3)."); //$NON-NLS-1$ //$NON-NLS-2$
	        }


	        // Test Case 4: Data Iterator
	        System.out.println("\nTest Case 4: Data Iterator"); //$NON-NLS-1$
	        Graph<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> dataGraph = new ArrayListGraph<>();
	        ArrayListGraphNode<Integer> dataNode1 = dataGraph.addNode("DataNode1"); //$NON-NLS-1$
	        ArrayListGraphNode<Integer> dataNode2 = dataGraph.addNode("DataNode2"); //$NON-NLS-1$
	        ArrayListGraphEdge<Integer> dataEdge1 = dataGraph.addEdge("DataEdge1", dataNode1, dataNode2); //$NON-NLS-1$

	        dataNode1.addData(100);
	        dataNode1.addData(101);
	        dataNode2.addData(200);
	        dataEdge1.addData(300);

	        Set<Integer> expectedData = new HashSet<>(Arrays.asList(100, 101, 200, 300));
	        Set<Integer> actualData = new HashSet<>();
	        Iterator<Integer> dataIter = dataGraph.dataIterator(); // Use the dataIterator method

	        int dataCount = 0;
	        try {
	            while (dataIter.hasNext()) {
	                Integer data = dataIter.next();
	                actualData.add(data);
	                dataCount++;
	            }
	            if (dataCount == expectedData.size() && actualData.equals(expectedData)) {
	                System.out.println("  PASS: Data iterator visited " + dataCount + " unique data items. Terminated successfully."); //$NON-NLS-1$ //$NON-NLS-2$
	            } else {
	                System.err.println("  FAIL: Data iterator expected " + expectedData.size() + " unique data, got " + dataCount + ". Actual: " + actualData + ", Expected: " + expectedData + " (Test 4)."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
	            }
	        } catch (NoSuchElementException e) {
	            System.err.println("  FAIL: Data iterator threw NoSuchElementException prematurely (Test 4)."); //$NON-NLS-1$
	        } catch (Exception e) {
	            System.err.println("  FAIL: Data iterator encountered unexpected exception: " + e.getMessage() + " (Test 4)."); //$NON-NLS-1$ //$NON-NLS-2$
	        }

	        System.out.println("\n--- Automated Verification Tests Finished ---"); //$NON-NLS-1$
	    } 
	 
    /**
     * @param args
     */
    @SuppressWarnings("boxing")
	public static void main(String[] args) {
        System.out.println("--- Graph Test Program (Part G) ---"); //$NON-NLS-1$

        // 1. Create a graph of integers.
        // We'll use our ArrayListGraph implementation, with Integer as data type.
        Graph<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> graph =
                new ArrayListGraph<>();
        System.out.println("\n1. Created a graph of Integers using ArrayListGraph."); //$NON-NLS-1$

        // Optionally, add a GraphListener to observe events
        GraphListener myGraphListener = new GraphListener() {
            @Override
            public void dataAdded(GraphDataEvent event) {
                System.out.println("[Listener] Data added: Source=" + event.getSource().getClass().getSimpleName() + ", Data=" + event.getData()); //$NON-NLS-1$ //$NON-NLS-2$
            }

            @Override
            public void dataRemoved(GraphDataEvent event) {
                System.out.println("[Listener] Data removed: Source=" + event.getSource().getClass().getSimpleName() + ", Data=" + event.getData()); //$NON-NLS-1$ //$NON-NLS-2$
            }
        };
        graph.addGraphListener(myGraphListener);
        System.out.println("Added a GraphListener to the graph for demonstration."); //$NON-NLS-1$

        // Create some nodes
        ArrayListGraphNode<Integer> nodeA = graph.addNode("NodeA"); //$NON-NLS-1$
        ArrayListGraphNode<Integer> nodeB = graph.addNode("NodeB"); //$NON-NLS-1$
        ArrayListGraphNode<Integer> nodeC = graph.addNode("NodeC"); //$NON-NLS-1$
        ArrayListGraphNode<Integer> nodeD = graph.addNode("NodeD"); //$NON-NLS-1$
        ArrayListGraphNode<Integer> nodeE = graph.addNode("NodeE"); //$NON-NLS-1$

        // Add some edges
        graph.addEdge("EdgeAB", nodeA, nodeB); //$NON-NLS-1$
        graph.addEdge("EdgeBC", nodeB, nodeC); //$NON-NLS-1$
        graph.addEdge("EdgeCD", nodeC, nodeD); //$NON-NLS-1$
        graph.addEdge("EdgeDE", nodeD, nodeE); //$NON-NLS-1$
        graph.addEdge("EdgeEA", nodeE, nodeA); // Create a cycle //$NON-NLS-1$
        graph.addEdge("EdgeAC", nodeA, nodeC); // Another edge //$NON-NLS-1$
        graph.addEdge("EdgeDB", nodeD, nodeB); // Cross edge //$NON-NLS-1$

        System.out.println("\nCreated initial nodes and edges."); //$NON-NLS-1$


        // 2. Add random integers to the nodes and edges.
        Random random = new Random();

        System.out.println("\n2. Adding random integers to nodes and edges..."); //$NON-NLS-1$
        for (GraphNode<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> node : graph.getNodes()) {
            int randomInt = random.nextInt(100); // Random int between 0 and 99
            node.addData(randomInt);
            System.out.println("  Added " + randomInt + " to " + node.getName()); //$NON-NLS-1$ //$NON-NLS-2$
        }

//        for (GraphEdge<ArrayListGraphNode<Integer>, ArrayListGraphEdge<Integer>, Integer> edge : graph.getEdges()) {
//            int randomInt = random.nextInt(100);
//            edge.addData(randomInt);
//            System.out.println("  Added " + randomInt + " to " + edge.getName()); //$NON-NLS-1$ //$NON-NLS-2$
//        }


        // 3. Display the nodes of the graph.
        System.out.println("\n3. Displaying nodes of the graph using GraphNodeIterator (no cycles):"); //$NON-NLS-1$
        // FIX: Directly instantiate GraphNodeIterator as Graph interface does not define nodeIterator()
        Iterator<ArrayListGraphNode<Integer>> nodeIteratorNoCycles = new GraphNodeIterator<>(graph, false); // false for no cycles
        int nodeCount = 0;
        while (nodeIteratorNoCycles.hasNext()) {
            GraphNode<?, ?, Integer> node = nodeIteratorNoCycles.next();
            System.out.println("  Node: " + node.getName() + ", Data: " + node.getData()); //$NON-NLS-1$ //$NON-NLS-2$
            nodeCount++;
        }
        System.out.println("Total nodes displayed (no cycles): " + nodeCount); //$NON-NLS-1$

        System.out.println("\n3. Displaying nodes of the graph using GraphNodeIterator (with cycles enabled):"); //$NON-NLS-1$
        // FIX: Directly instantiate GraphNodeIterator
        Iterator<ArrayListGraphNode<Integer>> nodeIteratorWithCycles = new GraphNodeIterator<>(graph, true); // true for cycles
        nodeCount = 0; // Reset count for this iteration
        while (nodeIteratorWithCycles.hasNext()) {
            GraphNode<?, ?, Integer> node = nodeIteratorWithCycles.next();
            System.out.println("  Node: " + node.getName() + ", Data: " + node.getData()); //$NON-NLS-1$ //$NON-NLS-2$
            nodeCount++;
        }
        System.out.println("Total nodes displayed (with cycles enabled, may show duplicates if enabled logic allows): " + nodeCount); //$NON-NLS-1$


        // 4. Display the integers stored in the graph.
        System.out.println("\n4. Displaying all integers stored in the graph using DataIterator:"); //$NON-NLS-1$
        int dataCount = 0;
        // The Graph interface still implements Iterable<D> and its default iterator() calls dataIterator()
        for (Integer data : graph) {
            System.out.println("  Data: " + data); //$NON-NLS-1$
            dataCount++;
        }
        System.out.println("Total integers displayed: " + dataCount); //$NON-NLS-1$
        

        System.out.println("==== Testing Cycling ===="); //$NON-NLS-1$
        testCycling();

        System.out.println("\n--- Test Program Finished ---"); //$NON-NLS-1$
    }
}