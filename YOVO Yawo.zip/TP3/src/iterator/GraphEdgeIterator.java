// iterator/GraphEdgeIterator.java
package iterator;

import model.GraphEdge;
import model.GraphNode;
import model.Graph;
import java.util.*; // For Collection, Queue, Set

/**
 * An iterator for traversing the edges of a graph.
 * It extends GraphElementIterator.
 *
 * As per UML: N>GraphEdge.
 *
 * @param <N> The type of GraphNode in the graph.
 * @param <E> The type of GraphEdge being iterated.
 * @param <D> The type of Data in the graph.
 */
public class GraphEdgeIterator<
        N extends GraphNode<N, E, D>,
        E extends GraphEdge<N, E, D>,
        D> extends GraphElementIterator<E> { // Iterates over E (GraphEdge)

    private final Graph<N, E, D> graph;
    private final Queue<E> queue; // Queue for edges
    private final Set<E> visitedEdges; // To avoid revisiting edges

    /**
     * Constructs a GraphEdgeIterator.
     * @param graph The graph to iterate over.
     */
    public GraphEdgeIterator(Graph<N, E, D> graph) {
        if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null for iteration."); //$NON-NLS-1$
        }
        this.graph = graph;
        this.queue = new LinkedList<>();
        this.visitedEdges = new HashSet<>();

        // Initialize the queue with all edges in the graph
        for (E edge : graph.getEdges()) {
            if (!this.visitedEdges.contains(edge)) {
                this.queue.offer(edge);
                this.visitedEdges.add(edge);
            }
        }
    }

    @Override
    public boolean hasNext() {
        return !this.queue.isEmpty();
    }

    @Override
    public E next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more edges in the graph."); //$NON-NLS-1$
        }
        return this.queue.poll(); // Simply return the next edge
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Remove operation is not supported by this iterator."); //$NON-NLS-1$
    }

	/**
	 * @return the graph of the iterator
	 */
	public Graph<N, E, D> getGraph() {
		return this.graph;
	}
}