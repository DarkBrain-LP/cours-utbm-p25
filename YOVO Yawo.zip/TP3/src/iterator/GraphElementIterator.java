// iterator/GraphElementIterator.java
package iterator;

import model.GraphElement; // Assuming N will be a GraphNode, which is a GraphElement
import java.util.Iterator;

/**
 * An abstract base class for iterators that traverse graph elements.
 * It implements the standard Java Iterator interface.
 * The generic parameter T represents the type of graph element being iterated over.
 *
 * As per UML: implements Iterator<T>.
 * The UML also implies N>GraphElement as a constraint for T in some contexts.
 *
 * @param <T> The type of GraphElement (e.g., GraphNode, GraphEdge) to be iterated.
 */
public abstract class GraphElementIterator<T extends GraphElement<?>> implements Iterator<T> {
    // No specific fields or methods are shown in the UML for GraphElementIterator itself,
    // other than it being an abstract implementation of Iterator.
    // Concrete implementations will provide the traversal logic.
}