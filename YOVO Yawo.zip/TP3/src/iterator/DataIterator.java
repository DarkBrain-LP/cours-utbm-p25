// iterator/DataIterator.java
package iterator;

import model.Graph;
import model.GraphNode;
import model.GraphEdge;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Collection;
import java.util.Collections;

/**
 * An iterator for traversing all data objects (D) stored within the nodes and edges of a graph.
 * implements Iterator<T> with {T > D}.
 *
 * @param <D> The type of data being iterated.
 */
public class DataIterator<D> implements Iterator<D> {

    private final Graph<?, ?, D> graph;
    private Iterator<D> currentDataIterator;
    private Iterator<? extends GraphNode<?, ?, D>> nodeIterator;
    private Iterator<? extends GraphEdge<?, ?, D>> edgeIterator;

    /**
     * Constructs a DataIterator.
     * @param graph The graph whose data is to be iterated.
     */
    public DataIterator(Graph<?, ?, D> graph) {
        if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null for data iteration."); //$NON-NLS-1$
        }
        this.graph = graph;
        this.nodeIterator = graph.getNodes().iterator(); // Start with node data
        this.edgeIterator = graph.getEdges().iterator(); // Will process edges after nodes
        this.currentDataIterator = Collections.<D>emptyList().iterator(); // Initialize with empty iterator
        advanceToNextDataCollection(); // Populate currentDataIterator initially
    }

    private void advanceToNextDataCollection() {
        // If current data iterator has more, no need to advance.
        if (this.currentDataIterator.hasNext()) {
            return;
        }

        // Try to get data from the next node
        while (this.nodeIterator.hasNext()) {
            Collection<D> nodeData = this.nodeIterator.next().getData();
            if (!nodeData.isEmpty()) {
                this.currentDataIterator = nodeData.iterator();
                if (this.currentDataIterator.hasNext()) {
                    return; // Found data in a node
                }
            }
        }

        // If no more data in nodes, try to get data from the next edge
        while (this.edgeIterator.hasNext()) {
            Collection<D> edgeData = this.edgeIterator.next().getData();
            if (!edgeData.isEmpty()) {
                this.currentDataIterator = edgeData.iterator();
                if (this.currentDataIterator.hasNext()) {
                    return; // Found data in an edge
                }
            }
        }

        this.currentDataIterator = Collections.<D>emptyList().iterator();
    }

    @Override
    public boolean hasNext() {
        advanceToNextDataCollection();
        return this.currentDataIterator.hasNext();
    }

    @Override
    public D next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more data in the graph."); //$NON-NLS-1$
        }
        return this.currentDataIterator.next();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Remove operation is not supported by this iterator."); //$NON-NLS-1$
    }

	/**
	 * @return the graph of the iterator
	 */
	public Graph<?, ?, D> getGraph() {
		return this.graph;
	}
}