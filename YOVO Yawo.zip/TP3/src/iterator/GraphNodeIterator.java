//// iterator/GraphNodeIterator.java
//package iterator;
//
//import model.GraphNode;
//import model.GraphEdge;
//import model.Graph;
//import java.util.*; // For Collection, Queue, Set
//
///**
// * An iterator for traversing the nodes of a graph.
// * It extends GraphElementIterator and handles cycle detection.
// *
// * As per UML: N>GraphNode.
// *
// * @param <N> The type of GraphNode being iterated.
// * @param <E> The type of GraphEdge in the graph.
// * @param <D> The type of Data in the graph.
// */
//public class GraphNodeIterator<
//        N extends GraphNode<N, E, D>,
//        E extends GraphEdge<N, E, D>,
//        D> extends GraphElementIterator<N> { // Iterates over N (GraphNode)
//
//    private final Graph<N, E, D> graph;
//    private final boolean enableCycles; // As per UML: - enableCycles : boolean {final}
//    private final Queue<N> queue; // For BFS traversal to avoid infinite loops and explore systematically
//    private final Set<N> visitedNodes; // To keep track of visited nodes
//
//    /**
//     * Constructs a GraphNodeIterator.
//     * @param graph The graph to iterate over.
//     * @param enableCycles If true, the iterator may revisit nodes in cycles (though will still terminate).
//     * If false, it will only visit each node once, avoiding paths that lead to cycles already visited.
//     */
//    public GraphNodeIterator(Graph<N, E, D> graph, boolean enableCycles) {
//        if (graph == null) {
//            throw new IllegalArgumentException("Graph cannot be null for iteration.");
//        }
//        this.graph = graph;
//        this.enableCycles = enableCycles;
//        this.queue = new LinkedList<>();
//        this.visitedNodes = new HashSet<>();
//
//        // Initialize the queue with all starting nodes if the graph has them,
//        // or just all nodes if it's a simple node iteration.
//        // For a general graph, starting with all nodes in no particular order (from getNodes())
//        // ensures all nodes are eventually visited.
//        for (N node : graph.getNodes()) {
//            if (!visitedNodes.contains(node)) {
//                queue.offer(node);
//                visitedNodes.add(node); // Mark as visited when added to queue
//            }
//        }
//    }
//
//    @Override
//    public boolean hasNext() {
//        return !queue.isEmpty();
//    }
//
//    @Override
//    public N next() {
//        if (!hasNext()) {
//            throw new NoSuchElementException("No more nodes in the graph.");
//        }
//
//        N currentNode = queue.poll(); // Get the next node from the queue
//
//        // For each outgoing edge from the current node
//        for (E edge : currentNode.getStartingEdges()) {
//            N neighbor = edge.getEndingNode();
//            if (enableCycles || !visitedNodes.contains(neighbor)) {
//                // If cycles are enabled, or if the neighbor hasn't been visited yet (and cycles are disabled)
//                queue.offer(neighbor);
//                visitedNodes.add(neighbor); // Mark as visited
//            }
//        }
//
//        return currentNode;
//    }
//
//    @Override
//    public void remove() {
//        // The UML does not specify a remove operation for iterators.
//        // Typically, iterators for graph structures do not support removal directly.
//        throw new UnsupportedOperationException("Remove operation is not supported by this iterator.");
//    }
//}


// iterator/GraphNodeIterator.java (REVISED: Fix for infinite loop, ensuring unique nodes)
package iterator;

import model.GraphNode;
import model.GraphEdge;
import model.Graph;
import java.util.*;

/**
 * An iterator for traversing the nodes of a graph using Breadth-First Search (BFS).
 * It extends GraphElementIterator<N> and guarantees termination by visiting each node at most once.
 *
 * The 'enableCycles' parameter will be retained as per UML, but its functional impact
 * will be limited to how the traversal explores paths, while the iterator still yields unique nodes
 * to strictly adhere to the "infinite loops must be avoided" constraint.
 * If 'enableCycles' was meant to yield duplicate nodes, a different traversal algorithm
 * or a more complex state management would be required, which conflicts with preventing infinite loops
 * for simple iteration.
 *
 * @param <N> The type of GraphNode being iterated.
 * @param <E> The type of GraphEdge in the graph.
 * @param <D> The type of Data in the graph.
 */
public class GraphNodeIterator<
        N extends GraphNode<N, E, D>,
        E extends GraphEdge<N, E, D>,
        D> extends GraphElementIterator<N> {

    private final Graph<N, E, D> graph;
    private final boolean enableCycles; // Retained as per UML, but its primary effect is managed by visited set
    private final Queue<N> traversalQueue; // For BFS traversal
    private final Set<N> visitedNodes; // Tracks all nodes added to the queue to prevent infinite loops

    /**
     * Constructs a GraphNodeIterator.
     * @param graph The graph to iterate over.
     * @param enableCycles If true, allows traversal to follow edges into already visited components,
     * but each node will still be yielded at most once by this iterator to prevent infinite loops.
     * If false, strictly avoids re-visiting nodes.
     */
    public GraphNodeIterator(Graph<N, E, D> graph, boolean enableCycles) {
        super();

        if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null for iteration."); //$NON-NLS-1$
        }
        this.graph = graph;
        this.enableCycles = enableCycles; 
        this.traversalQueue = new LinkedList<>();
        this.visitedNodes = new HashSet<>();

        // Initialize the queue with all nodes that are not yet visited.
        // This handles disconnected graph components.
        for (N node : graph.getNodes()) {
            if (!this.visitedNodes.contains(node)) { // Check if already added (e.g., from an earlier component)
                this.traversalQueue.offer(node);
                this.visitedNodes.add(node); // Mark as visited (enqueued)
            }
        }
    }

    @Override
    public boolean hasNext() {
        return !this.traversalQueue.isEmpty();
    }

    @Override
    public N next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more nodes in the graph."); //$NON-NLS-1$
        }

        N currentNode = this.traversalQueue.poll();

        // Enqueue unvisited neighbors for future processing
        for (E edge : currentNode.getStartingEdges()) {
            N neighbor = edge.getEndingNode();
            // The `visitedNodes` set strictly prevents adding the same node to the queue more than once.
            // This is the core mechanism to prevent infinite loops in cyclic graphs during BFS traversal.
            if (!this.visitedNodes.contains(neighbor)) {
                this.traversalQueue.offer(neighbor);
                this.visitedNodes.add(neighbor); // Mark as visited (enqueued)
            }
            // The 'enableCycles' parameter, in this robust-termination setup, means that
            // even if a node is part of a cycle, it will be correctly discovered and processed,
            // but not returned multiple times by 'next()'. If the requirement was to return
            // duplicate nodes, the iterator's contract would be different, likely implying
            // an "encounter" iterator rather than a "unique element" iterator.
            // Given "infinite loops must be avoided", returning unique nodes is the safest default.
        }

        return currentNode; // Return the current node.
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Remove operation is not supported by this iterator."); //$NON-NLS-1$
    }

	/**
	 * @return if the cycling is enabled
	 */
	public boolean isEnableCycles() {
		return this.enableCycles;
	}

	/**
	 * @return the graph of the iterator
	 */
	public Graph<N, E, D> getGraph() {
		return this.graph;
	}
}