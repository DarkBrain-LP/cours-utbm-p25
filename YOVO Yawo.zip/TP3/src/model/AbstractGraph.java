package model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import factory.GraphFactory;
import observer.GraphDataEvent;
import observer.GraphListener;

/**
 * An abstract base class for a graph structure. It provides common graph-level
 * functionalities, including managing a collection of observers (listeners).
 *
 * @param <N> The specific type of AbstractGraphNode used in this graph.
 * @param <E> The specific type of AbstractGraphEdge used in this graph.
 * @param <D> The type of data stored within the graph's elements (nodes and/or edges).
 */
public abstract class AbstractGraph<
        N extends AbstractGraphNode<N, E, D>,
        E extends AbstractGraphEdge<N, E, D>,
        D> implements Graph<N, E, D> {

    protected Collection<GraphListener> observers; 

    /**
     * Constructor for AbstractGraph.
     */
    public AbstractGraph() {
        this.observers = new ArrayList<>();
    }

    @Override
    public void addGraphListener(GraphListener observer) {
        if (observer != null && !this.observers.contains(observer)) {
            this.observers.add(observer);
        }
    }

    @Override
    public void removeGraphListener(GraphListener observer) {
        if (observer != null) {
            this.observers.remove(observer);
        }
    }

    /**
     * An internal helper method to notify graph listeners about various events.
     * This can be called by concrete graph implementations when nodes/edges are added/removed, etc.
     *
     * @param event The graph data event to fire.
     */
    protected void fireGraphEvent(GraphDataEvent event) {
        for (GraphListener listener : this.observers) {
            // Depending on the event type, call the specific listener method
            if (event.getData() != null) {
                // This is a simplification; ideally, we'd have specific event types
                // like NodeAddedEvent, EdgeAddedEvent, etc.
                listener.dataAdded(event); // Or dataRemoved, etc.
            } 
//            else if (event.getOldName() != null || event.getNewName() != null) {
//                listener.nameChanged(event);
//            }
        }
    }

    // The following methods from the Graph interface remain abstract as their
    // implementation depends on the concrete storage mechanism (e.g., arrays, collections).
    @Override
    public abstract GraphFactory<N, E, D> getFactory();

    @Override
    public abstract Collection<N> getNodes();

    @Override
    public abstract Collection<E> getEdges();

    @Override
    public abstract N addNode(String name);

    @Override
    public abstract void addNode(N node);

    @Override
    public abstract E addEdge(String name, N start, N end);

    @Override
    public abstract void addEdge(E edge, N start, N end);

    @Override
    public abstract Iterator<D> iterator(); // Required by Iterable<D>
}