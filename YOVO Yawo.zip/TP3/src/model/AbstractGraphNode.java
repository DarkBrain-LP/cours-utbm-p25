package model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * An abstract base class for graph nodes. It extends AbstractGraphElement
 * and provides common node-specific functionalities like managing connected edges.
 *
 * @param <N> The specific type of AbstractGraphNode itself for self-referencing.
 * @param <E> The specific type of AbstractGraphEdge for edges connected to this node.
 * @param <D> The type of data stored within this node.
 */
public abstract class AbstractGraphNode<
        N extends AbstractGraphNode<N, E, D>,
        E extends AbstractGraphEdge<N, E, D>,
        D> extends AbstractGraphElement<N, E, D> implements GraphNode<N, E, D> {

    protected Collection<E> startingEdges;
    protected Collection<E> finishingEdges;

    /**
     * Constructor for AbstractGraphNode.
     * @param name The initial name of the node.
     */
    public AbstractGraphNode(String name) {
        super(name);
        this.startingEdges = new ArrayList<>();
        this.finishingEdges = new ArrayList<>();
    }

    @Override
    public Collection<E> getStartingEdges() {
        return Collections.unmodifiableCollection(this.startingEdges);
    }

    @Override
    public Collection<E> getFinishingEdges() {
        return Collections.unmodifiableCollection(this.finishingEdges);
    }

    @Override
    public void connectStartingEdge(E edge) {
        if (edge == null) {
            throw new IllegalArgumentException("Edge cannot be null."); //$NON-NLS-1$
        }
        if (edge.getStartingNode() != this) {
            throw new IllegalArgumentException("Edge's starting node must be this node."); //$NON-NLS-1$
        }
        if (!this.startingEdges.contains(edge)) {
            this.startingEdges.add(edge);
        }
    }

    @Override
    public void connectFinishingEdge(E edge) {
        if (edge == null) {
            throw new IllegalArgumentException("Edge cannot be null."); //$NON-NLS-1$
        }
        if (edge.getEndingNode() != this) {
            throw new IllegalArgumentException("Edge's ending node must be this node."); //$NON-NLS-1$
        }
        if (!this.finishingEdges.contains(edge)) {
            this.finishingEdges.add(edge);
        }
    }
}