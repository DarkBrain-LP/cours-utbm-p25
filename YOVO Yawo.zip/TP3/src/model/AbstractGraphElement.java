package model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import observer.GraphDataEvent;
import observer.GraphListener;

/**
 * An abstract base class providing common functionality for all graph elements (nodes and edges).
 * It includes support for naming, data storage, and an observer pattern for event notification.
 *
 * @param <N> The specific type of Node.
 * @param <E> The specific type of Edge. Strictly following UML: E extends AbstractGraphElement<N, E, D>.
 * @param <D> The type of data stored within this graph element.
 */
public abstract class AbstractGraphElement<
        N extends AbstractGraphElement<N, E, D>,
        E extends AbstractGraphElement<N, E, D>,
        D> implements GraphElement<D> {

    protected String name;
    protected Collection<D> dataStorage;
    protected Collection<GraphListener> observers;

    /**
     * Constructor for AbstractGraphElement.
     * @param name The initial name of the graph element.
     */
    public AbstractGraphElement(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Graph element name cannot be null or empty."); //$NON-NLS-1$
        }
        this.name = name;
        this.dataStorage = new ArrayList<>();
        this.observers = new ArrayList<>();
    }

    @Override
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name of this graph element and fires a name changed event.
     * @param newName The new name for the element.
     */
    public void setName(String newName) {
        if (newName == null || newName.trim().isEmpty()) {
            throw new IllegalArgumentException("Graph element name cannot be null or empty."); //$NON-NLS-1$
        }
        String oldName = this.name;
        if (!oldName.equals(newName)) {
            this.name = newName;
        }
    }

    @Override
    public void addData(D data) {
        if (data == null) {
            throw new IllegalArgumentException("Data cannot be null."); //$NON-NLS-1$
        }
        if (this.dataStorage.add(data)) {
            fireDataAdded(new GraphDataEvent(this, data));
        }
    }

    @Override
    public void removeData(D data) {
        if (data == null) {
            throw new IllegalArgumentException("Data cannot be null."); //$NON-NLS-1$
        }
        if (this.dataStorage.remove(data)) {
            fireDataRemoved(new GraphDataEvent(this, data));
        }
    }

    @Override
    public Collection<D> getData() {
        return Collections.unmodifiableCollection(this.dataStorage);
    }

    @Override
    public void addGraphListener(GraphListener listener) {
        if (listener != null && !this.observers.contains(listener)) {
            this.observers.add(listener);
        }
    }

    @Override
    public void removeGraphListener(GraphListener listener) {
        if (listener != null) {
            this.observers.remove(listener);
        }
    }

    @Override
    public abstract Graph<?, ?, D> getGraph();
    
    /**
     * Notifies all registered listeners that data has been added to this element.
     * Uses a GraphDataEvent object.
     * @param event The event object containing details about the added data.
     */
    protected void fireDataAdded(GraphDataEvent event) { // Use wildcards for source as it can be N, E or this
        for (GraphListener listener : this.observers) {
            listener.dataAdded(event);
        }
    }

    /**
     * Convenience method to notify all registered listeners that data has been added to this element.
     * Creates a simple GraphDataEvent internally.
     * @param data The data that was added.
     */
    protected void fireDataAdded(D data) {
        fireDataAdded(new GraphDataEvent(this, data));
    }


    /**
     * Notifies all registered listeners that data has been removed from this element.
     * Uses a GraphDataEvent object.
     * @param event The event object containing details about the removed data.
     */
    protected void fireDataRemoved(GraphDataEvent event) {
        for (GraphListener listener : this.observers) {
            listener.dataRemoved(event);
        }
    }

    /**
     * Convenience method to notify all registered listeners that data has been removed from this element.
     * Creates a simple GraphDataEvent internally.
     * @param data The data that was removed.
     */
    protected void fireDataRemoved(D data) {
        fireDataRemoved(new GraphDataEvent(this, data));
    }

}