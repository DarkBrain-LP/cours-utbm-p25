// GraphElement.java
package model;

import java.util.Collection;

import observer.GraphListener;

/**
 * Represents a generic element within a graph, such as a node or an edge.
 * It supports associating data and an event listening mechanism.
 *
 * @param <D> The type of data stored within this graph element.
 */
public interface GraphElement<D> {

    /**
     * Retrieves the name of this graph element.
     * @return The name of the graph element.
     */
    String getName();

    /**
     * Adds data to this graph element.
     * @param data The data to be added.
     */
    void addData(D data);

    /**
     * Removes specific data from this graph element.
     * @param data The data to be removed.
     */
    void removeData(D data);

    /**
     * Retrieves a collection of all data associated with this graph element.
     * @return A collection of data.
     */
    Collection<D> getData();

    /**
     * Adds a listener to be notified of events related to this graph element.
     * @param listener The listener to add.
     */
    void addGraphListener(GraphListener listener);

    /**
     * Removes a listener from this graph element.
     * @param listener The listener to remove.
     */
    void removeGraphListener(GraphListener listener);

    /**
     * Retrieves the graph to which this element belongs.
     * @return The parent graph.
     */
    Graph<?, ?, D> getGraph();
}