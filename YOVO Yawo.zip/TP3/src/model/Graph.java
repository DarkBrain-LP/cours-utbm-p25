package model;

import java.util.Collection;
import java.util.Iterator;

import factory.GraphFactory;
import observer.GraphListener;

/**
 * Represents a generic graph structure, composed of nodes and edges.
 * It provides methods for managing graph elements and graph-level data.
 *
 * @param <N> The specific type of nodes in this graph.
 * @param <E> The specific type of edges in this graph.
 * @param <D> The type of data stored within graph elements (nodes and/or edges).
 */
public interface Graph<N extends GraphNode<N, E, D>, E extends GraphEdge<N, E, D>, D>
        extends Iterable<D> { 

    /**
     * Retrieves the factory responsible for creating elements for this graph.
     * @return The graph factory.
     */
    GraphFactory<N, E, D> getFactory();

    /**
     * Retrieves a collection of all nodes in the graph.
     * @return A collection of nodes.
     */
    Collection<N> getNodes();

    /**
     * Retrieves a collection of all edges in the graph.
     * @return A collection of all edges.
     */
    Collection<E> getEdges();

    /**
     * Creates and adds a new node to the graph.
     * This method uses the graph's factory to create the node.
     * @param name The name of the node.
     * @return The newly created and added node.
     */
    N addNode(String name);

    /**
     * Adds an existing node to the graph.
     * @param node The node to add.
     */
    void addNode(N node);

    /**
     * Creates and adds a new edge to the graph, connecting the specified start and end nodes.
     * This method uses the graph's factory to create the edge.
     * @param name The name of the edge.
     * @param start The starting node of the edge.
     * @param end The ending node of the edge.
     * @return The newly created and added edge.
     */
    E addEdge(String name, N start, N end);

    /**
     * Adds an existing edge to the graph, connecting the specified start and end nodes.
     * @param edge The edge to add.
     * @param start The starting node of the edge.
     * @param end The ending node of the edge.
     */
    void addEdge(E edge, N start, N end);

    /**
     * Adds a listener to be notified of events related to the graph.
     * @param observer The listener to add.
     */
    void addGraphListener(GraphListener observer);

    /**
     * Removes a listener from the graph.
     * @param observer The listener to remove.
     */
    void removeGraphListener(GraphListener observer);

    /**
     * Returns an iterator over elements of type {@code D} (data) in this graph.
     * This method fulfills the contract of the {@code Iterable} interface.
     * @return An iterator over the data elements of the graph.
     */
    @Override
    Iterator<D> iterator();

	/**
	 * @return the iterator on data
	 */
	Iterator<D> dataIterator();
}