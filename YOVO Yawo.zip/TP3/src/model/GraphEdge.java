package model;


/**
 * Represents a generic edge in a graph structure.
 * Edges connect two nodes and can store data.
 *
 * @param <N> The specific type of GraphNode that this edge connects.
 * @param <E> The specific type of GraphEdge itself (for self-referencing generics).
 * @param <D> The type of data stored within this edge.
 */
public interface GraphEdge<N extends GraphNode<N, E, D>, E extends GraphEdge<N, E, D>, D>
        extends GraphElement<D> {

    /**
     * Retrieves the starting node of this edge.
     * @return The starting node.
     */
    N getStartingNode();

    /**
     * Retrieves the ending node of this edge.
     * @return The ending node.
     */
    N getEndingNode();
}