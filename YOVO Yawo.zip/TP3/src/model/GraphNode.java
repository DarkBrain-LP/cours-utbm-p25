package model;

import java.util.Collection;

/**
 * Represents a generic node in a graph structure.
 * Nodes can be connected by edges and can store data.
 *
 * @param <N> The specific type of GraphNode itself (for self-referencing generics).
 * @param <E> The specific type of GraphEdge that connects nodes in this graph.
 * @param <D> The type of data stored within this node.
 */
public interface GraphNode<N extends GraphNode<N, E, D>, E extends GraphEdge<N, E, D>, D>
        extends GraphElement<D> {

    /**
     * Retrieves a collection of edges that start at this node.
     * @return A collection of starting edges.
     */
    Collection<E> getStartingEdges();

    /**
     * Retrieves a collection of edges that finish at this node.
     * @return A collection of finishing edges.
     */
    Collection<E> getFinishingEdges();

    /**
     * Connects a new edge that starts at this node.
     * @param edge The edge to connect.
     */
    void connectStartingEdge(E edge);

    /**
     * Connects a new edge that finishes at this node.
     * @param edge The edge to connect.
     */
    void connectFinishingEdge(E edge);
}