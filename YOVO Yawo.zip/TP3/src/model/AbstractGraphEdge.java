package model;

/**
 * An abstract base class for graph edges. It extends AbstractGraphElement
 * and provides common edge-specific functionalities like storing references to its connected nodes.
 *
 * @param <N> The specific type of AbstractGraphNode that this edge connects.
 * @param <E> The specific type of AbstractGraphEdge itself for self-referencing.
 * @param <D> The type of data stored within this edge.
 */
public abstract class AbstractGraphEdge<
        N extends AbstractGraphNode<N, E, D>,
        E extends AbstractGraphEdge<N, E, D>,
        D> extends AbstractGraphElement<N, E, D> implements GraphEdge<N, E, D> {

    protected N startNode; 
    protected N endNode; 

    /**
     * Constructor for AbstractGraphEdge.
     * @param name The initial name of the edge.
     * @param startNode The starting node of the edge.
     * @param endNode The ending node of the edge.
     */
    public AbstractGraphEdge(String name, N startNode, N endNode) {
        super(name);
        if (startNode == null || endNode == null) {
            throw new IllegalArgumentException("Start and end nodes cannot be null."); //$NON-NLS-1$
        }
        this.startNode = startNode;
        this.endNode = endNode;
    }

    @Override
    public N getStartingNode() {
        return this.startNode;
    }

    @Override
    public N getEndingNode() {
        return this.endNode;
    }
}