package observer;

import java.util.EventObject; 

/**
 * Represents an event that occurs within a graph, containing information
 * corresponding to a modification of data in a graph element.
 * This class serves as the event object in the Observer pattern.
 */
public class GraphDataEvent extends EventObject { 

	private static final long serialVersionUID = 8100370603112775935L;
	private final Object data; // The data involved in the event

    /**
     * Constructs a GraphDataEvent.
     * @param source The object on which the Event initially occurred (e.g., a GraphElement or Graph).
     * @param data The data object related to the event (e.g., added or removed data).
     */
    public GraphDataEvent(Object source, Object data) {
        super(source);
        this.data = data;
    }

    /**
     * Retrieves the data object associated with this event.
     * @return The data object.
     */
    public Object getData() {
        return this.data;
    }
}