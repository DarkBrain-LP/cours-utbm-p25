package observer;

import java.util.EventListener; 

/**
 * Interface for listeners that want to be notified of graph-related events.
 * This represents an observer in the Observer pattern.
 */
public interface GraphListener extends EventListener {

    /**
     * Called when data is added to a graph element or the graph itself.
     * @param event The event details.
     */
    void dataAdded(GraphDataEvent event);

    /**
     * Called when data is removed from a graph element or the graph itself.
     * @param event The event details.
     */
    void dataRemoved(GraphDataEvent event);
}