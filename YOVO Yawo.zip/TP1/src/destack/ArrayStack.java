package destack;

import java.util.Arrays;
import java.util.Iterator; 

/**
 * An implementation of the {@code Stack} interface that uses a dynamic array
 * to store elements. This stack grows as needed to store new elements.
 *
 * @param <T> The type of elements held in the stack.
 */
public class ArrayStack<T> extends AbstractStack<T> {

    /**
     * The array used to store elements of the stack.
     */
    private T[] content;

    
    private int index; // represents the last item's index of the stack

    /**
     * Constructs an empty {@code ArrayStack}
     */
    @SuppressWarnings("unchecked")
	public ArrayStack() {
    	this.content = (T[]) new Object[0];
    	this.index = -1; // set to -1 so the first push will insert to the array position 0
    }



    /**
     * Pushes an element onto the top of this stack. If the internal array is full,
     * it will be resized.
     *
     * @param data The element to be pushed onto the stack.
     */
    @Override
    public void push(T data) {
        ensureCapacity();
        this.content[++this.index] = data;
        fireDataAdded(); // Notify listeners that data has been added
    }

    /**
     * Removes and returns the element at the top of this stack.
     *
     * @return The element at the top of this stack.
     * @throws EmptyStackException If this stack is empty.
     */
    @Override
    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        T data = this.content[this.index];
        this.content[this.index--] = null; // Clear reference to old object for garbage collection
        fireDataRemoved(); // Notify listeners that data has been removed
        return data;
    }

    /**
     * Returns the number of elements in this stack.
     *
     * @return The number of elements in this stack.
     */
    @Override
    public int size() {
    	return this.index+1;
//        return top;
    }

    /**
     * Increases the capacity of the internal array if it is full.
     * The new capacity will be double the current capacity.
     */
    private void ensureCapacity() {
        if (this.index <= this.content.length-1) {
            int newCapacity = this.content.length == 0 ? 1 : this.content.length + 1;
            this.content = Arrays.copyOf(this.content, newCapacity);
        }
    }

    /**
     * Returns a string representation of the stack.
     *
     * @return A string containing the elements of the stack, from bottom to top.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("["); //$NON-NLS-1$
        for (int i = 0; i <= this.index; i++) {
            sb.append(this.content[i]);
            if (i < this.index) {
                sb.append(", "); //$NON-NLS-1$
            }
        }
        sb.append("]"); //$NON-NLS-1$
        return sb.toString();
    }

    /**
     * Returns an iterator over the elements in this stack in LIFO (Last-In, First-Out) order.
     *
     * @return an {@link Iterator} over the elements in this stack.
     */
    @Override
    public Iterator<T> iterator() {
        return new StackIterator();
    }

    /**
     * Private inner class implementing the Iterator for ArrayStack.
     * It iterates from the top of the stack downwards (LIFO order).
     */
    private class StackIterator implements Iterator<T> {
        private int currentIndex = ArrayStack.this.index; // Start from the top element

        /**
         * Returns {@code true} if the iteration has more elements.
         * (In other words, returns {@code true} if {@link #next} would
         * return an element rather than throwing an exception.)
         *
         * @return {@code true} if the iteration has more elements
         */
        @Override
        public boolean hasNext() {
            return this.currentIndex >= 0;
        }

        /**
         * Returns the next element in the iteration.
         *
         * @return the next element in the iteration
         * @throws java.util.NoSuchElementException if the iteration has no more elements
         */
        @Override
        public T next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            return ArrayStack.this.content[this.currentIndex--];
        }

        /**
         * Removes from the underlying collection the last element returned by this iterator.
         * This operation is not supported for this iterator.
         *
         * @throws UnsupportedOperationException if the {@code remove} operation
         * is not supported by this iterator
         */
        @Override
        public void remove() {
            throw new UnsupportedOperationException("remove() is not supported by this iterator."); //$NON-NLS-1$
        }
    }
}
