package destack;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * An abstract base class for implementing a stack.
 * This class provides common functionality for managing stack listeners
 * and checking if the stack is empty. Subclasses must implement the
 * specific storage mechanism and the push/pop operations.
 *
 * @param <T> The type of elements held in this stack.
 */
public abstract class AbstractStack<T> implements Stack<T> {

    /**
     * A list of listeners that will be notified of stack events
     */
    protected List<StackListener> listeners = new ArrayList<>();

    /**
     * Constructs a new AbstractStack.
     */
    public AbstractStack() {
        // Default constructor
    }

    /**
     * Checks if this stack is empty
     */
    @Override
    public boolean isEmpty() {
        return size() == 0;
    }


    /**
     * Adds a listener to this stack.
     *
     * @param listener The {@code StackListener} to be added.
     */
    @Override
    public void addStackListener(StackListener listener) {
        if (listener != null) {
        	this.listeners.add(listener);
        }
    }

    /**
     * Removes a listener from this stack.
     *
     * @param listener The {@code StackListener} to be removed.
     */
    @Override
    public void removeStackListener(StackListener listener) {
        if (listener != null) {
            this.listeners.remove(listener);
        }
    }

    /**
     * Notifies all registered listeners that data has been added to the stack.
     * This method is protected as it's intended to be called by subclasses
     * after a push operation.
     */
    protected void fireDataAdded() {
        for (StackListener listener : this.listeners) {
            listener.dataAdded(this);
        }
    }

    /**
     * Notifies all registered listeners that data has been removed from the stack.
     * This method is protected as it's intended to be called by subclasses
     * after a pop operation.
     */
    protected void fireDataRemoved() {
        for (StackListener listener : this.listeners) {
            listener.dataRemoved(this);
        }
    }

    // Abstract methods that must be implemented by concrete subclasses
    @Override
    public abstract void push(T data);
    @Override
    public abstract T pop();
    @Override
    public abstract int size();

    // The iterator() method will be implemented by children.
    @Override
    public abstract Iterator<T> iterator();
}