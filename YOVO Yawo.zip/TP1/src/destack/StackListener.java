package destack;

/**
 * A listener interface for receiving notifications about changes to a stack.
 * Implementations of this interface can be registered with a {@code Stack}
 * to be informed when elements are added or removed.
 */
public interface StackListener {

    /**
     * Called when data has been added to the stack.
     *
     * @param stack The {@code Stack} instance that had data added.
     */
    void dataAdded(Stack<?> stack); 

    /**
     * Called when data has been removed from the stack.
     *
     * @param stack The {@code Stack} instance that had data removed.
     */
    void dataRemoved(Stack<?> stack);
}