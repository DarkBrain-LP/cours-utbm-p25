package destack;

import java.util.Random;

/**
 * The main class to demonstrate the usage of the custom Stack implementation.
 * It demonstrates push, pop, size, isEmpty, listener functionality, and sorting.
 * Fulfills the requirements of "D) Test Program".
 */
public class Main {

    /**
     * The main method to run the demonstration.
     *
     * @param args Command line arguments (not used in this demo).
     */
    public static void main(String[] args) {
        System.out.println("--- Demonstrating ArrayStack ---"); //$NON-NLS-1$

        // 1. Create a stack of integers.
        Stack<Integer> intStack = new ArrayStack<>();

        // Add a StackListener to observe operations
        StackListener myListener = new StackListener() {
            @Override
            public void dataAdded(Stack<?> stack) {
                System.out.println("Listener: Data added to stack. Current size: " + stack.size()); //$NON-NLS-1$
            }

            @Override
            public void dataRemoved(Stack<?> stack) {
                System.out.println("Listener: Data removed from stack. Current size: " + stack.size()); //$NON-NLS-1$
            }
        };
        intStack.addStackListener(myListener);

        System.out.println("Is stack empty? " + intStack.isEmpty()); // Should be true //$NON-NLS-1$
        System.out.println("Stack size: " + intStack.size()); // Should be 0 //$NON-NLS-1$

        // 2. Add a random number of random integers to the stack.
        System.out.println("\n--- Adding random elements ---"); //$NON-NLS-1$
        Random random = new Random();
        
     // Add between 5 and 9 elements
        int numberOfElements = 5 + random.nextInt(5);
        for (int i = 0; i < numberOfElements; i++) {
        	// Push random integers between 0-99
            intStack.push(Integer.valueOf(random.nextInt(100)));
        }

        // 3. Display the contents of the stack.
        System.out.println("Stack after adding elements: " + intStack); //$NON-NLS-1$
        System.out.println("Is stack empty? " + intStack.isEmpty()); //$NON-NLS-1$
        System.out.println("Stack size: " + intStack.size()); //$NON-NLS-1$

        // Demonstrate popping some elements
        System.out.println("\n--- Popping a few elements ---"); //$NON-NLS-1$
        try {
            if (!intStack.isEmpty()) {
                System.out.println("Popped: " + intStack.pop()); //$NON-NLS-1$
            }
            if (!intStack.isEmpty()) {
                System.out.println("Popped: " + intStack.pop()); //$NON-NLS-1$
            }
            System.out.println("Stack after some pops: " + intStack); //$NON-NLS-1$
        } catch (EmptyStackException e) {
            System.err.println("Error during pop: " + e.getMessage()); //$NON-NLS-1$
        }

        System.out.println("\n--- Iterating through stack (LIFO) ---"); //$NON-NLS-1$
        for (Integer item : intStack) {
            System.out.println("Item from iterator: " + item); //$NON-NLS-1$
        }

        // 4. Sort the stack.
        System.out.println("\n--- Sorting the stack ---"); //$NON-NLS-1$
        Sorter sorter = new AscendentOrderSorter();
        sorter.sort(intStack);

        // 5. Display the contents of the 'sorted' stack.
        System.out.println("Stack after sorting (ascending order): " + intStack); //$NON-NLS-1$

        // Verify order by popping all elements from the sorted stack
        System.out.println("\n--- Popping sorted stack to verify order ---"); //$NON-NLS-1$
        while (!intStack.isEmpty()) {
            System.out.println("Popped: " + intStack.pop()); //$NON-NLS-1$
        }

        // Test EmptyStackException
        System.out.println("\n--- Testing EmptyStackException on empty stack ---"); //$NON-NLS-1$
        try {
            intStack.pop(); // This should throw EmptyStackException
        } catch (EmptyStackException e) {
            System.err.println("Successfully caught EmptyStackException: " + e.getMessage()); //$NON-NLS-1$
        }

        // Demonstrate removing listener
        System.out.println("\n--- Demonstrating listener removal ---"); //$NON-NLS-1$
        intStack.removeStackListener(myListener);
        
        // This push should NOT trigger a listener message
        intStack.push(Integer.valueOf(999));
        System.out.println("Pushed 999 to stack after listener removal. No listener message expected."); //$NON-NLS-1$
        System.out.println("Stack now: " + intStack); //$NON-NLS-1$
    }
}