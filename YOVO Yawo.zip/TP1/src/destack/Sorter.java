package destack;

/**
 * Defines the contract for sorting operations on a stack.
 */
public interface Sorter {

    /**
     * Sorts the elements in the given stack according to a specific order.
     *
     * @param stack The {@code Stack} to be sorted.
     */
    void sort(Stack<?> stack); // Use ? so that the Sorter might work on any type of Stack
}