package destack;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * An implementation of the {@code Sorter} interface that sorts the elements
 * in a stack in ascendent (ascending) order.
 * This sorter is designed to work with any {@code Stack<?>}, but will throw a
 * {@code ClassCastException} at runtime if the elements within the stack
 * are not mutually {@code Comparable}.
 */
public class AscendentOrderSorter implements Sorter { // No generic type parameter here as per your Sorter interface

    /**
     * Constructs a new AscendentOrderSorter.
     */
    public AscendentOrderSorter() {
        // Default constructor
    }

    /**
     * Sorts the elements in the given stack in ascending order.
     * The sorting is performed by popping all elements into a temporary list,
     * sorting the list, and then pushing the sorted elements back onto the stack.
     *
     * @param stack The {@code Stack} to be sorted.
     * @throws ClassCastException If elements in the stack are not mutually comparable.
     */
    @Override
    @SuppressWarnings("unchecked") // Suppress warning for unsafe operations due to Stack<?>
    public void sort(Stack<?> stack) {
        if (stack == null || stack.isEmpty()) {
            return;
        }

        List<Comparable<Object>> tempContainer = new ArrayList<>();
        // Pop all elements from the stack into the temporary list
        try {
            // Need to cast the stack to a raw type to pop elements into a Comparable list
            // This is necessary because Stack<?>'s pop() returns Object, and we need to treat them as Comparable
            Stack<?> rawStack = stack; // Use raw type to suppress compiler warnings on `pop` for type inference.
            while (!rawStack.isEmpty()) {
                // Runtime check: if elements are not Comparable, a ClassCastException will occur here or during Collections.sort
                tempContainer.add((Comparable<Object>) rawStack.pop());
            }
        } catch (EmptyStackException e) {
            System.err.println("Error during stack pop while sorting: " + e.getMessage()); //$NON-NLS-1$
            return;
        } catch (ClassCastException e) {
             System.err.println("Error: Elements in the stack are not comparable: " + e.getMessage()); //$NON-NLS-1$
             throw e; // Re-throw to indicate the issue
        }

        // Sort the temporary list. This assumes all elements are mutually comparable.
        // If not, a ClassCastException will be thrown at runtime by Collections.sort.
        Collections.sort(tempContainer);

        // Push the sorted elements back onto the stack
        for (Comparable<Object> element : tempContainer) {
            // Need to cast the stack back to raw type for push, or push Object type.
            // Pushing Comparable<Object> into Stack<?> is fine as Stack<?> accepts any type for push.
            ((Stack<Object>) stack).push(element); // Cast to Stack<Object> for push to match accepted type
        }
    }
}