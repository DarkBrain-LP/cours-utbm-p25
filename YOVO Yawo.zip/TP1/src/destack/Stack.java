///**
// * 
// */
//package destack;
//
///**
// * @param <T> 
// * 
// */
//public interface Stack<T> {
//	/**
//	 * @param data
//	 */
//	void push(T data);
//	/**
//	 * @return the last added item of the stack
//	 * no need of public because the default visibility of method in interface is public
//	 */
//	T pop();
//	/**
//	 * @return if the function stack is empty or not
//	 */
//	boolean isEmpty();
//	/**
//	 * @return the size of the stack
//	 */
//	int size();
////	public void addStackListener();
////	public void removeStackListener();
//}

package destack;
import java.util.Iterator; // Import for the Iterator interface

/**
 * Represents a generic stack data structure that allows elements to be pushed and popped.
 * This interface extends the {@code Iterable} interface, allowing the stack to be
 * used in a for-each loop.
 *
 * @param <T> The type of elements held in this stack.
 */
public interface Stack<T> extends Iterable<T> {

    /**
     * Pushes an element onto the top of this stack.
     *
     * @param data The element to be pushed onto the stack.
     */
    void push(T data);

    /**
     * Removes and returns the element at the top of this stack.
     *
     * @return The element at the top of this stack.
     * @throws java.util.EmptyStackException If this stack is empty.
     */
    T pop();

    /**
     * Checks if this stack is empty.
     *
     * @return {@code true} if this stack contains no elements, {@code false} otherwise.
     */
    boolean isEmpty();

    /**
     * Returns the number of elements in this stack.
     *
     * @return The number of elements in this stack.
     */
    int size();

    /**
     * Adds a listener to this stack. The listener will be notified when data is added
     * to or removed from the stack.
     *
     * @param listener The {@code StackListener} to be added.
     */
    void addStackListener(StackListener listener);

    /**
     * Removes a listener from this stack.
     *
     * @param listener The {@code StackListener} to be removed.
     */
    void removeStackListener(StackListener listener);

    /**
     * Returns an iterator over elements of type {@code T}.
     *
     * @return an {@link Iterator}.
     */
    @Override
    Iterator<T> iterator(); // Required by Iterable interface
}