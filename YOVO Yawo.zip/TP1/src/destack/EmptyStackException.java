package destack;

/**
 * Custom exception indicating that an operation was attempted on an empty stack.
 * This class extends {@code RuntimeException} as it's typically an unchecked exception.
 */
public class EmptyStackException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = -8629306330095801257L;

	/**
     * Constructs a new {@code EmptyStackException} with no detail message.
     */
    public EmptyStackException() {
        super();
    }

    /**
     * Constructs a new {@code EmptyStackException} with the specified detail message.
     *
     * @param message The detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     */
    public EmptyStackException(String message) {
        super(message);
    }

    /**
     * Constructs a new {@code EmptyStackException} with the specified detail message and cause.
     *
     * @param message The detail message.
     * @param cause The cause (which is saved for later retrieval by the {@link #getCause()} method).
     */
    public EmptyStackException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new {@code EmptyStackException} with the specified cause and a detail
     * message of `(cause==null ? null : cause.toString())` (which typically contains the
     * class and detail message of `cause`). This constructor is useful for exceptions
     * that are little more than wrappers for other throwables.
     *
     * @param cause The cause.
     */
    public EmptyStackException(Throwable cause) {
        super(cause);
    }
}