/* 
 * File:   UART_LIN.c
 * Author: aravey
 *
 * Created on 12 april 2020, 13:42
 */

#include "UART_LIN.h"

//Functions

//UART_Init() sets up the UART for a 8-bit data, No Parity, 1 Stop bit
//at 9600 baud with transmitter interrupts enabled
void UART_Init (void)
{
 
        
}


/*--- Transmit LIN Message ---*/

void SendMessage(LINMSG *msg)
  {

  }

/*--- Transmit LIN Request ---*/

void SendRequest(LINMSG *msg)
  {

  }


/*--- Send sync field and break ---*/

void sync_break(void)
  {

  }

/*--- Transmit char ---*/
 
void UART_PutChar(uint8_t data)
  {

  }

/*--- Calculate lin checksum ---*/

uint8_t checksum(uint8_t length, uint8_t *data)
  {
  uint8_t ix;
  uint16_t check_sum = 0;

  for(ix = 0; ix < length-1; ix++)
    {
    check_sum += data[ix];
    if(check_sum >= 256){
      check_sum -= 255;
      }
    }

  return (uint8_t)(0xff - check_sum);
  }
